import { StudentProfile, CareerRecommendation, CareerRoadmap, ResumeAnalysisResult, AgentToolInfo } from '../types';

export const DEMO_STUDENT: StudentProfile = {
  id: 'demo-rahul-01',
  name: 'Rahul',
  college: 'Apex Institute of Technology',
  degree: 'B.Tech CSE',
  branch: 'Computer Science & Engineering',
  year: '2nd Year',
  currentSkills: ['Python', 'SQL', 'HTML', 'CSS'],
  interests: ['Artificial Intelligence', 'Machine Learning', 'Data Science'],
  experienceLevel: 'Beginner',
  preferredCareer: 'AI/ML Engineer',
  careerGoal: 'Become an AI/ML Engineer at a high-growth tech company or AI research lab',
  resumeText: `RAHUL SHARMA
Email: rahul.cse@example.com | GitHub: github.com/rahul-dev | LinkedIn: linkedin.com/in/rahul-ai
Education:
- B.Tech in Computer Science & Engineering (2nd Year, CGPA: 8.4/10)
  Apex Institute of Technology, 2024 - 2028

Technical Skills:
- Programming Languages: Python, SQL, HTML5, CSS3
- Familiar Tools: Git, VS Code, SQLite, Jupyter Notebook
- Foundational Knowledge: Object-Oriented Programming, Data Structures & Algorithms (Basics)

Academic Projects:
1. Student Performance Predictor (Python, Pandas, SQLite)
   - Created a CLI tool using Python to analyze student grades and calculate GPA trends.
   - Stored records in SQLite database and generated summary statistics.

2. Personal Portfolio Website (HTML, CSS, JavaScript)
   - Developed a responsive personal website hosted on GitHub Pages.
   - Structured semantic HTML and styled layouts using CSS Grid and Flexbox.

Interests & Activities:
- Active member of Campus Coding Club
- Participated in College Hackathon 2025 (Ideated an AI tutor concept)
- Eager to master Machine Learning, PyTorch, and Deep Learning architectures.`,
  resumeFileName: 'Rahul_Sharma_Resume.pdf'
};

export const INITIAL_AI_RECOMMENDATION: CareerRecommendation = {
  recommendedCareer: 'AI/ML Engineer',
  matchPercentage: 86,
  explanation: 'Your solid foundation in Python and SQL, combined with 2nd-year academic CS coursework, provides an ideal launchpad for AI/ML Engineering. Python is the industry lingua franca for ML frameworks (PyTorch, scikit-learn), while SQL gives you the critical ability to extract, clean, and manipulate production training datasets.',
  requiredSkills: ['Python', 'SQL', 'Linear Algebra & Calculus', 'NumPy & Pandas', 'scikit-learn', 'PyTorch / TensorFlow', 'Model Deployment (FastAPI/Docker)', 'MLOps Basics'],
  currentSkillStrengths: ['Python (Syntax & OOP)', 'SQL (Queries & Relational Schema)', 'Web UI Foundations (HTML/CSS for rapid prototyping)'],
  missingSkills: ['Linear Algebra & Probability for ML', 'Data Wrangling (NumPy & Pandas)', 'Classical ML Algorithms (Regression, Trees, SVMs)', 'Deep Learning (PyTorch / Transformers)', 'Model Serving & APIs'],
  recommendedProjects: [
    {
      title: 'End-to-End Housing Price Predictor with Feature Engineering',
      description: 'Build and evaluate regression models with scikit-learn, perform cross-validation, and serve predictions via a lightweight FastAPI microservice.',
      techStack: ['Python', 'Pandas', 'scikit-learn', 'FastAPI'],
      difficulty: 'Beginner'
    },
    {
      title: 'Semantic Document Search using Embeddings & Vector DB',
      description: 'Ingest PDF lecture notes or research papers, compute text embeddings, and perform cosine similarity search with ChromaDB.',
      techStack: ['Python', 'Sentence-Transformers', 'ChromaDB', 'Streamlit'],
      difficulty: 'Intermediate'
    },
    {
      title: 'Fine-Tuned LLM Customer Assistant with RAG Pipeline',
      description: 'Implement Retrieval-Augmented Generation using LangChain/LlamaIndex on custom college documents, with evaluation metrics.',
      techStack: ['Python', 'PyTorch', 'LangChain', 'Docker'],
      difficulty: 'Advanced'
    }
  ]
};

export const DEFAULT_AI_ROADMAP: CareerRoadmap = {
  career: 'AI/ML Engineer',
  totalEstimatedWeeks: 24,
  description: 'A structured, semester-friendly progressive roadmap tailored for 2nd-year CS students moving from foundational code to production-grade AI.',
  steps: [
    {
      id: 'step-1',
      title: 'Python Mastery & Computational Foundations',
      category: 'Programming',
      estimatedTime: '3 Weeks',
      status: 'completed',
      description: 'Solidify Python data structures, list comprehensions, generators, object-oriented design, and clean code practices.',
      tasks: [
        { id: 't1-1', title: 'Master Python OOP, decorators, and type hints', completed: true },
        { id: 't1-2', title: 'Solve 25+ LeetCode problems on Arrays, Strings, and Hashmaps', completed: true },
        { id: 't1-3', title: 'Set up virtual environments (venv/conda) and Git workflow', completed: true }
      ],
      skillsAcquired: ['Python 3', 'OOP', 'Data Structures', 'Git Version Control'],
      recommendedResources: [
        { name: 'Core Python & Algorithms by Real Python', type: 'Documentation' },
        { name: 'NeetCode 150 - Array & Hashing Track', type: 'Practice' }
      ]
    },
    {
      id: 'step-2',
      title: 'Mathematics & Statistics for Machine Learning',
      category: 'Mathematics',
      estimatedTime: '3 Weeks',
      status: 'in-progress',
      description: 'Learn the exact mathematical concepts underpinning ML: Matrix operations, eigenvalues, partial derivatives, gradient descent, and Bayes theorem.',
      tasks: [
        { id: 't2-1', title: 'Understand matrix multiplication, vector norms, and rank', completed: true },
        { id: 't2-2', title: 'Study cost functions, gradients, and multivariate calculus', completed: false },
        { id: 't2-3', title: 'Learn probability distributions, expectation, and hypothesis testing', completed: false }
      ],
      skillsAcquired: ['Linear Algebra', 'Multivariate Calculus', 'Probability & Statistics'],
      recommendedResources: [
        { name: 'Essence of Linear Algebra by 3Blue1Brown', type: 'Course' },
        { name: 'Mathematics for Machine Learning (Deisenroth)', type: 'Book' }
      ]
    },
    {
      id: 'step-3',
      title: 'NumPy, Pandas & Exploratory Data Analysis',
      category: 'Data Wrangling',
      estimatedTime: '3 Weeks',
      status: 'in-progress',
      description: 'Gain fluency in vectorization, broadcasting, DataFrame slicing, missing value imputation, and visual distribution analysis.',
      tasks: [
        { id: 't3-1', title: 'Vectorized operations and broadcasting with NumPy arrays', completed: true },
        { id: 't3-2', title: 'Data cleaning, groupby aggregations, and joins with Pandas', completed: false },
        { id: 't3-3', title: 'Data visualization with Matplotlib and Seaborn', completed: false }
      ],
      skillsAcquired: ['NumPy', 'Pandas', 'Matplotlib', 'Seaborn', 'EDA'],
      recommendedResources: [
        { name: 'Python for Data Analysis (Wes McKinney)', type: 'Book' },
        { name: 'Kaggle Learn: Pandas & Data Visualization', type: 'Practice' }
      ]
    },
    {
      id: 'step-4',
      title: 'Classical Machine Learning with scikit-learn',
      category: 'Core ML',
      estimatedTime: '4 Weeks',
      status: 'upcoming',
      description: 'Understand regression, decision trees, random forests, gradient boosting (XGBoost), clustering, and validation techniques.',
      tasks: [
        { id: 't4-1', title: 'Implement Linear & Logistic Regression from scratch and sklearn', completed: false },
        { id: 't4-2', title: 'Ensemble methods: Random Forests, AdaBoost, XGBoost', completed: false },
        { id: 't4-3', title: 'Cross-validation, hyperparameter tuning (GridSearchCV), ROC-AUC metrics', completed: false }
      ],
      skillsAcquired: ['scikit-learn', 'Supervised Learning', 'Unsupervised Learning', 'Model Evaluation'],
      recommendedResources: [
        { name: 'Hands-On Machine Learning (Aurélien Géron)', type: 'Book' },
        { name: 'Andrew Ng Machine Learning Specialization', type: 'Course' }
      ]
    },
    {
      id: 'step-5',
      title: 'Deep Learning & Neural Networks with PyTorch',
      category: 'Deep Learning',
      estimatedTime: '5 Weeks',
      status: 'upcoming',
      description: 'Explore neural network backpropagation, PyTorch autograd, CNNs for computer vision, RNNs/Transformers for NLP, and modern LLM mechanics.',
      tasks: [
        { id: 't5-1', title: 'Tensors, computational graphs, and loss optimization in PyTorch', completed: false },
        { id: 't5-2', title: 'Build and train a Convolutional Neural Network on CIFAR-10', completed: false },
        { id: 't5-3', title: 'Understand Self-Attention and Transformer architecture basics', completed: false }
      ],
      skillsAcquired: ['PyTorch', 'Neural Networks', 'CNNs', 'Attention & Transformers'],
      recommendedResources: [
        { name: 'Deep Learning with PyTorch (official tutorials)', type: 'Documentation' },
        { name: 'Fast.ai Practical Deep Learning for Coders', type: 'Course' }
      ]
    },
    {
      id: 'step-6',
      title: 'Capstone AI Projects & Model Deployment',
      category: 'Portfolio',
      estimatedTime: '3 Weeks',
      status: 'upcoming',
      description: 'Package trained models into production-ready REST APIs using FastAPI, containerize with Docker, and host on cloud infrastructure.',
      tasks: [
        { id: 't6-1', title: 'Build a RAG system using LangChain/LlamaIndex and ChromaDB', completed: false },
        { id: 't6-2', title: 'Create REST endpoints with FastAPI for real-time model inference', completed: false },
        { id: 't6-3', title: 'Write clean Dockerfile and deploy to cloud (Cloud Run / Hugging Face Spaces)', completed: false }
      ],
      skillsAcquired: ['FastAPI', 'Docker', 'RAG Pipelines', 'Vector Databases', 'Cloud Deployment'],
      recommendedResources: [
        { name: 'Full Stack Deep Learning Course', type: 'Course' },
        { name: 'FastAPI Production Guide', type: 'Documentation' }
      ]
    },
    {
      id: 'step-7',
      title: 'Technical Interview & System Design Preparation',
      category: 'Career Prep',
      estimatedTime: '3 Weeks',
      status: 'upcoming',
      description: 'Practice ML coding questions, behavioral stories (STAR method), ML system design patterns, and resume defense.',
      tasks: [
        { id: 't7-1', title: 'Practice 30+ ML interview conceptual questions', completed: false },
        { id: 't7-2', title: 'Study ML System Design: Recommendation systems, search ranking', completed: false },
        { id: 't7-3', title: 'Conduct AI Mock Interviews on CareerPilot AI', completed: false }
      ],
      skillsAcquired: ['ML System Design', 'Technical Problem Solving', 'Behavioral Communication'],
      recommendedResources: [
        { name: 'Machine Learning System Design by Chip Huyen', type: 'Book' },
        { name: 'CareerPilot AI Mock Interview Simulator', type: 'Practice' }
      ]
    }
  ]
};

export const DEMO_RESUME_ANALYSIS: ResumeAnalysisResult = {
  score: 76,
  atsScore: 79,
  fileName: 'Rahul_Sharma_Resume.pdf',
  summary: 'Good foundational resume for a 2nd-year B.Tech CSE student. Clear academic record and programming fundamentals in Python and SQL. To compete effectively for top tier AI/ML internships, the resume must replace basic HTML/CSS portfolio projects with domain-specific ML pipelines, feature engineering, and quantifiable performance metrics.',
  strengths: [
    'Clear, high-contrast academic background with GPA and relevant graduation timeline.',
    'Demonstrated Python proficiency and SQLite database integration in project work.',
    'Active campus engagement and hackathon experience shows self-motivated initiative.',
    'Clean, scannable contact details including GitHub and LinkedIn profiles.'
  ],
  weaknesses: [
    'Projects lack quantifiable metrics (e.g. accuracy scores, latency reduction, dataset volume).',
    'HTML/CSS portfolio project dilutes the focus away from the declared AI/ML target role.',
    'Missing essential ML libraries: NumPy, Pandas, scikit-learn, PyTorch are absent.',
    'Bullet points describe generic tasks rather than accomplishments and problem impact.'
  ],
  missingSkills: [
    'NumPy & Pandas',
    'scikit-learn',
    'Model Evaluation (Precision, Recall, ROC-AUC)',
    'FastAPI / REST Model Serving',
    'PyTorch / Deep Learning'
  ],
  suggestedImprovements: [
    {
      section: 'Projects: Student Performance Predictor',
      currentIssue: 'Bullet says "Created a CLI tool using Python to analyze student grades and calculate GPA trends."',
      suggestedRevision: 'Developed a predictive analytics pipeline using Python and Pandas on 500+ student records; optimized SQLite queries for 40% faster aggregation and visualized semester GPA distributions.'
    },
    {
      section: 'Technical Skills',
      currentIssue: 'Listed HTML/CSS as core technical skills for an AI/ML aspirant.',
      suggestedRevision: 'Reorganize into: Languages (Python, SQL), Libraries & Frameworks (NumPy, Pandas, scikit-learn), Tools (Git, Docker, Jupyter), Concepts (Data Structures, OOP, Regression).'
    },
    {
      section: 'Experience / Hackathon',
      currentIssue: 'Passive wording: "Participated in College Hackathon 2025 (Ideated an AI tutor concept)."',
      suggestedRevision: 'Spearheaded a 4-person hackathon team to architect an AI Tutor MVP; integrated prompt-engineered study guides and earned Top 10 Finalist recognition among 60 teams.'
    }
  ],
  recommendedProjects: [
    {
      name: 'ML Credit Risk or Churn Classifier with Explainable AI',
      rationale: 'Demonstrates end-to-end data preprocessing, cross-validation, and SHAP feature importance analysis.',
      stack: ['Python', 'Pandas', 'scikit-learn', 'SHAP', 'Streamlit']
    },
    {
      name: 'Real-time Object Classification or OCR Engine',
      rationale: 'Demonstrates PyTorch proficiency and computer vision pipeline experience on public datasets.',
      stack: ['Python', 'PyTorch', 'OpenCV', 'FastAPI']
    }
  ],
  atsFeedback: {
    keywordMatchRate: 74,
    formattingStatus: 'Good',
    missingKeySections: ['Certifications', 'Relevant Coursework (Linear Algebra, DBMS)'],
    actionVerbStrength: 'Moderate'
  }
};

export const AGENT_TOOLS_REGISTRY: AgentToolInfo[] = [
  {
    name: 'analyze_student_profile',
    description: 'Inspects academic level, degrees, declared technical skills, and user aspirations to synthesize a student profile vector.',
    parameters: ['name', 'degree', 'year', 'skills', 'interests', 'experienceLevel'],
    purpose: 'Constructs baseline context and skill readiness matrix.',
    category: 'Profiling & Context'
  },
  {
    name: 'recommend_career',
    description: 'Computes matching affinity against modern industry roles (e.g. AI/ML Engineer, Full Stack, Data Scientist) based on current skillset.',
    parameters: ['currentSkills', 'interests', 'careerGoal'],
    purpose: 'Determines highest-fit career pathways and calculates alignment percentages.',
    category: 'Career Intelligence'
  },
  {
    name: 'analyze_skill_gap',
    description: 'Compares student competencies against enterprise job requirements, identifying strengths, partial proficiencies, and critical deficits.',
    parameters: ['targetRole', 'currentSkills', 'experienceLevel'],
    purpose: 'Maps exact gaps preventing the student from clearing technical screenings.',
    category: 'Gap Analysis'
  },
  {
    name: 'generate_learning_roadmap',
    description: 'Constructs an interactive, milestone-based step-by-step curriculum with estimated timelines, tasks, and vetted resources.',
    parameters: ['targetRole', 'currentSkills', 'availableTimeWeeks'],
    purpose: 'Generates actionable semester-friendly learning progression.',
    category: 'Learning Planning'
  },
  {
    name: 'analyze_resume',
    description: 'Performs automated ATS scoring, bullet-point impact evaluation, keyword compliance checks, and project suggestions on PDF/text resumes.',
    parameters: ['resumeContent', 'targetRole'],
    purpose: 'Transforms college resumes into high-converting technical documents.',
    category: 'Document Audit'
  },
  {
    name: 'generate_interview_question',
    description: 'Generates targeted technical or behavioral interview questions tailored to the chosen career, experience level, and difficulty tier.',
    parameters: ['career', 'experienceLevel', 'difficulty', 'previousQuestions'],
    purpose: 'Tests candidate depth with progressive difficulty and relevant college-to-industry scenarios.',
    category: 'Evaluation Engine'
  },
  {
    name: 'evaluate_interview_answer',
    description: 'Assesses student answers for correctness, technical rigor, communication clarity, missed edge cases, and provides a polished model response.',
    parameters: ['question', 'studentAnswer', 'career', 'difficulty'],
    purpose: 'Provides constructive, immediate feedback with numerical scoring and sample ideal answers.',
    category: 'Evaluation Engine'
  }
];

export const DEMO_CAREER_RECOMMENDATION = INITIAL_AI_RECOMMENDATION;
export const DEMO_ROADMAP = DEFAULT_AI_ROADMAP;
