import React, { createContext, useContext, useState, useCallback, useRef } from 'react';

export type AgentStatusType = 'online' | 'thinking' | 'ready' | 'error';

interface AgentStatusContextValue {
  status: AgentStatusType;
  statusText: string;
  subMessage: string;
  reportThinking: (subMessage?: string) => void;
  reportReady: (subMessage?: string) => void;
  reportOnline: () => void;
  reportError: (subMessage?: string, retryFn?: () => void) => void;
  retryAction: (() => void) | null;
}

const AgentStatusContext = createContext<AgentStatusContextValue | undefined>(undefined);

export const AgentStatusProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [status, setStatus] = useState<AgentStatusType>('online');
  const [subMessage, setSubMessage] = useState<string>('AI Agent is selecting the best available model...');
  const [retryAction, setRetryAction] = useState<(() => void) | null>(null);
  const resetTimerRef = useRef<NodeJS.Timeout | null>(null);

  const clearTimer = () => {
    if (resetTimerRef.current) {
      clearTimeout(resetTimerRef.current);
      resetTimerRef.current = null;
    }
  };

  const reportThinking = useCallback((message: string = 'AI Agent is selecting the best available model...') => {
    clearTimer();
    setStatus('thinking');
    setSubMessage(message);
    setRetryAction(null);
  }, []);

  const reportReady = useCallback((message: string = 'AI is optimizing your request...') => {
    clearTimer();
    setStatus('ready');
    setSubMessage(message);

    // After 3.5 seconds of displaying "✓ Agent Ready", transition back to "● Agent Online"
    resetTimerRef.current = setTimeout(() => {
      setStatus('online');
      setSubMessage('');
    }, 3500);
  }, []);

  const reportOnline = useCallback(() => {
    clearTimer();
    setStatus('online');
    setSubMessage('');
    setRetryAction(null);
  }, []);

  const reportError = useCallback((message: string = 'AI temporarily unavailable — Retry', retryFn?: () => void) => {
    clearTimer();
    setStatus('error');
    setSubMessage(message);
    if (retryFn) {
      setRetryAction(() => retryFn);
    }
  }, []);

  let statusText = '● Agent Online';
  if (status === 'thinking') statusText = '◉ Agent Thinking...';
  if (status === 'ready') statusText = '✓ Agent Ready';
  if (status === 'error') statusText = '⚠ AI temporarily unavailable — Retry';

  return (
    <AgentStatusContext.Provider
      value={{
        status,
        statusText,
        subMessage,
        reportThinking,
        reportReady,
        reportOnline,
        reportError,
        retryAction
      }}
    >
      {children}
    </AgentStatusContext.Provider>
  );
};

export function useAgentStatus() {
  const context = useContext(AgentStatusContext);
  if (!context) {
    throw new Error('useAgentStatus must be used within an AgentStatusProvider');
  }
  return context;
}
