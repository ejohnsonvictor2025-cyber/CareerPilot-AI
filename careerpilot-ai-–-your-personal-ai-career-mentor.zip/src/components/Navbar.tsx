import React, { useState } from 'react';
import { 
  Compass, 
  Sparkles, 
  User, 
  Cpu, 
  FileText, 
  Map, 
  MessageSquare, 
  Mic, 
  LayoutDashboard, 
  Menu, 
  X, 
  Check, 
  Zap
} from 'lucide-react';
import { ActiveTab, StudentProfile } from '../types';
import { AgentStatusIndicator } from './AgentStatusIndicator';

interface NavbarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  isDemoMode: boolean;
  onToggleDemoMode: () => void;
  onOpenAgentModal: () => void;
  profile: StudentProfile;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  isDemoMode,
  onToggleDemoMode,
  onOpenAgentModal,
  profile
}) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navItems: { tab: ActiveTab; label: string; icon: React.ElementType }[] = [
    { tab: 'landing', label: 'Home', icon: Compass },
    { tab: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { tab: 'profile', label: 'Profile', icon: User },
    { tab: 'advisor', label: 'AI Advisor', icon: MessageSquare },
    { tab: 'roadmap', label: 'Roadmap', icon: Map },
    { tab: 'resume', label: 'Resume', icon: FileText },
    { tab: 'interview', label: 'Mock Interview', icon: Mic }
  ];

  return (
    <header className="fixed top-0 left-0 right-0 z-40 w-full h-16 border-b border-slate-800/80 bg-slate-950/90 backdrop-blur-xl transition-all">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 h-full">
        <div className="flex items-center justify-between h-full gap-2">
          {/* Brand Logo - Compact, No Wrapping */}
          <div 
            onClick={() => setActiveTab('landing')}
            className="flex items-center gap-2.5 sm:gap-3 cursor-pointer group select-none shrink-0"
          >
            <div className="relative shrink-0">
              <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-purple-600 flex items-center justify-center text-white shadow-lg shadow-indigo-500/25 group-hover:scale-105 transition-transform">
                <Compass className="w-5 h-5 animate-pulse" />
              </div>
              <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-indigo-500"></span>
              </span>
            </div>
            <div className="flex flex-col whitespace-nowrap">
              <div className="flex items-center gap-1.5 leading-none">
                <span className="text-base sm:text-lg font-extrabold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white via-slate-100 to-indigo-200">
                  CareerPilot
                </span>
                <span className="text-base sm:text-lg font-black text-indigo-400">
                  AI
                </span>
                <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 tracking-wide uppercase">
                  Agent
                </span>
              </div>
              <p className="text-[10px] sm:text-[11px] text-slate-400 font-medium tracking-tight whitespace-nowrap mt-0.5">
                Your Personal AI Career Mentor
              </p>
            </div>
          </div>

          {/* Desktop Navigation Links - Horizontal, No Text Wrapping */}
          <nav className="hidden lg:flex items-center gap-0.5 xl:gap-1 shrink-0">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.tab;
              return (
                <button
                  key={item.tab}
                  onClick={() => setActiveTab(item.tab)}
                  className={`flex items-center gap-1.5 px-2.5 xl:px-3 py-1.5 rounded-lg text-[11px] xl:text-xs font-semibold whitespace-nowrap transition-all ${
                    isActive
                      ? 'bg-indigo-600/30 text-indigo-200 border border-indigo-500/50 shadow-sm shadow-indigo-950/50 font-bold'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800/70 border border-transparent'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 shrink-0 ${isActive ? 'text-indigo-400' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Right Action Controls */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            {/* AI Agent Status Indicator */}
            <div className="hidden sm:flex items-center">
              <AgentStatusIndicator />
            </div>

            {/* AI Architecture Modal Trigger */}
            <button
              onClick={onOpenAgentModal}
              className="hidden md:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold bg-slate-900/80 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700/80 transition-all hover:border-indigo-500/50 whitespace-nowrap"
              title="Inspect Agent Reasoning Pipeline & Tools"
            >
              <Cpu className="w-3.5 h-3.5 text-purple-400 shrink-0" />
              <span className="hidden 2xl:inline">Agent System</span>
              <span className="2xl:hidden hidden sm:inline">Agent</span>
            </button>

            {/* Demo Mode Switch for College Competition */}
            <button
              onClick={onToggleDemoMode}
              className={`flex items-center gap-1.5 px-2 sm:px-2.5 py-1.5 rounded-lg text-xs font-bold transition-all border shadow-sm whitespace-nowrap ${
                isDemoMode
                  ? 'bg-gradient-to-r from-emerald-600/30 to-teal-600/30 text-emerald-300 border-emerald-500/50 hover:bg-emerald-600/40'
                  : 'bg-slate-900/80 text-slate-300 border-slate-700 hover:bg-slate-800 hover:text-white'
              }`}
              title="Click to toggle preloaded sample student for competition judges"
            >
              <Zap className={`w-3.5 h-3.5 shrink-0 ${isDemoMode ? 'text-emerald-400 fill-emerald-400' : 'text-amber-400'}`} />
              <span className="hidden sm:inline">Demo:</span>
              <span className={isDemoMode ? 'text-emerald-300' : 'text-slate-400'}>
                {isDemoMode ? 'Rahul' : 'Off'}
              </span>
            </button>

            {/* Profile Avatar / Quick Switch */}
            <button
              onClick={() => setActiveTab('profile')}
              className={`flex items-center gap-1.5 sm:gap-2 pl-1.5 sm:pl-2 pr-2 py-1 rounded-xl border transition-all text-left whitespace-nowrap ${
                activeTab === 'profile'
                  ? 'bg-indigo-600/25 border-indigo-500/60 text-indigo-200 shadow-sm shadow-indigo-950/50'
                  : 'bg-slate-900 border-slate-800 hover:border-indigo-500/50 text-slate-200'
              }`}
              title="View student profile"
            >
              <div className="w-6 h-6 rounded-full bg-gradient-to-tr from-indigo-500 to-purple-600 flex items-center justify-center text-[10px] font-bold text-white uppercase shrink-0">
                {profile.name ? profile.name[0] : 'S'}
              </div>
              <span className="text-xs font-semibold hidden 2xl:inline max-w-[85px] truncate">
                {profile.name || 'Profile'}
              </span>
            </button>

            {/* Mobile / Tablet Menu Button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              aria-label="Toggle navigation menu"
            >
              {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile / Tablet Drawer Menu */}
      {isMobileMenuOpen && (
        <div className="fixed top-16 left-0 right-0 z-40 lg:hidden border-b border-slate-800 bg-slate-950/95 backdrop-blur-2xl px-4 pt-3 pb-5 space-y-3 shadow-2xl max-h-[calc(100vh-4rem)] overflow-y-auto">
          <div className="pb-2 border-b border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
            <AgentStatusIndicator />
            <button
              onClick={() => {
                onOpenAgentModal();
                setIsMobileMenuOpen(false);
              }}
              className="flex items-center gap-1.5 text-indigo-400 hover:text-indigo-300 font-semibold"
            >
              <Cpu className="w-3.5 h-3.5 text-purple-400" />
              <span>Agent System</span>
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.tab;
              return (
                <button
                  key={item.tab}
                  onClick={() => {
                    setActiveTab(item.tab);
                    setIsMobileMenuOpen(false);
                  }}
                  className={`flex items-center gap-2 p-2.5 rounded-xl text-xs font-semibold text-left transition-all ${
                    isActive
                      ? 'bg-indigo-600/30 text-indigo-200 border border-indigo-500/50 shadow-sm'
                      : 'text-slate-300 hover:bg-slate-900 border border-slate-800/60'
                  }`}
                >
                  <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-indigo-400' : 'text-slate-400'}`} />
                  <span className="truncate">{item.label}</span>
                </button>
              );
            })}
          </div>

          <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs">
            <span className="text-slate-400">Active Student:</span>
            <span className="font-semibold text-white truncate max-w-[220px]">
              {profile.name} ({profile.year || '2nd Year'})
            </span>
          </div>
        </div>
      )}
    </header>
  );
};
