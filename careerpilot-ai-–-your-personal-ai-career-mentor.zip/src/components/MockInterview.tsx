import React, { useState, useEffect } from 'react';
import { 
  Mic, 
  MicOff, 
  Send, 
  Sparkles, 
  Play, 
  CheckCircle2, 
  Clock, 
  RotateCcw, 
  Award, 
  Layers, 
  Cpu, 
  Zap, 
  ChevronRight, 
  BookOpen, 
  HelpCircle,
  BarChart3
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { StudentProfile, InterviewQuestion, InterviewEvaluation } from '../types';
import { fetchInterviewQuestion, evaluateInterviewAnswer } from '../api/client';
import { useAgentStatus } from '../context/AgentStatusContext';

interface MockInterviewProps {
  profile: StudentProfile;
  onUpdateInterviewScore: (score: number) => void;
}

export const MockInterview: React.FC<MockInterviewProps> = ({
  profile,
  onUpdateInterviewScore
}) => {
  const { reportThinking, reportReady, reportError } = useAgentStatus();
  // Setup state
  const [selectedCareer, setSelectedCareer] = useState(profile.preferredCareer || 'AI/ML Engineer');
  const [selectedExperience, setSelectedExperience] = useState('College Student / Fresher');
  const [selectedDifficulty, setSelectedDifficulty] = useState('Intermediate');
  const [hasStarted, setHasStarted] = useState(false);

  // Active question state
  const [currentQuestion, setCurrentQuestion] = useState<InterviewQuestion | null>(null);
  const [questionIndex, setQuestionIndex] = useState(1);
  const [studentAnswer, setStudentAnswer] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [evaluation, setEvaluation] = useState<InterviewEvaluation | null>(null);
  const [showHints, setShowHints] = useState(false);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [completedSessions, setCompletedSessions] = useState<number[]>([]);
  const [isFinished, setIsFinished] = useState(false);
  const [askedQuestions, setAskedQuestions] = useState<string[]>([]);

  // Timer
  useEffect(() => {
    let timer: any = null;
    if (hasStarted && !evaluation && !isFinished) {
      timer = setInterval(() => {
        setElapsedSeconds(prev => prev + 1);
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [hasStarted, evaluation, isFinished]);

  const formatTimer = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const handleStartInterview = async () => {
    setHasStarted(true);
    setIsFinished(false);
    setQuestionIndex(1);
    setEvaluation(null);
    setElapsedSeconds(0);
    setCompletedSessions([]);
    reportThinking("AI Agent is selecting the best available model & question...");

    try {
      const q = await fetchInterviewQuestion({
        career: selectedCareer,
        difficulty: selectedDifficulty,
        experienceLevel: selectedExperience,
        questionNumber: 1,
        previousQuestions: []
      });
      setCurrentQuestion(q);
      setAskedQuestions([q.question]);
      reportReady();
    } catch (e) {
      console.info("Question setup handled:", e);
      reportError("AI temporarily unavailable — Retry", handleStartInterview);
    }
  };

  const handleSubmitAnswer = async () => {
    if (!currentQuestion || !studentAnswer.trim() || isSubmitting) return;

    setIsSubmitting(true);
    reportThinking("AI is optimizing your request & evaluating depth...");
    try {
      const evalResult = await evaluateInterviewAnswer({
        question: currentQuestion.question,
        studentAnswer,
        career: selectedCareer,
        difficulty: selectedDifficulty
      });

      setEvaluation(evalResult);
      const newScores = [...completedSessions, evalResult.score];
      setCompletedSessions(newScores);

      const avgScore = newScores.reduce((a, b) => a + b, 0) / newScores.length;
      onUpdateInterviewScore(avgScore);

      if (evalResult.score >= 8.5) {
        confetti({
          particleCount: 80,
          spread: 60,
          origin: { y: 0.6 }
        });
      }
      reportReady();
    } catch (e) {
      console.info("Answer evaluation handled:", e);
      reportError("AI temporarily unavailable — Retry", handleSubmitAnswer);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleNextQuestion = async () => {
    if (questionIndex >= 3) {
      setIsFinished(true);
      return;
    }

    setEvaluation(null);
    setStudentAnswer('');
    setShowHints(false);
    setElapsedSeconds(0);
    const nextIdx = questionIndex + 1;
    setQuestionIndex(nextIdx);
    reportThinking("AI Agent is selecting the best available model & question...");

    try {
      const nextQ = await fetchInterviewQuestion({
        career: selectedCareer,
        difficulty: selectedDifficulty,
        experienceLevel: selectedExperience,
        questionNumber: nextIdx,
        previousQuestions: askedQuestions
      });
      setCurrentQuestion(nextQ);
      setAskedQuestions(prev => [...prev, nextQ.question]);
      reportReady();
    } catch (e) {
      console.info("Next question handled:", e);
      reportError("AI temporarily unavailable — Retry", handleNextQuestion);
    }
  };

  // Web Speech recognition for voice answering
  const handleToggleVoice = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert("Speech recognition is not supported in this browser. Please type your answer.");
      return;
    }

    if (isListening) {
      setIsListening(false);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = false;
      recognition.lang = 'en-US';

      recognition.onstart = () => setIsListening(true);
      recognition.onresult = (event: any) => {
        let transcript = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            transcript += event.results[i][0].transcript;
          }
        }
        if (transcript) {
          setStudentAnswer(prev => (prev ? `${prev} ${transcript}` : transcript));
        }
      };
      recognition.onerror = () => setIsListening(false);
      recognition.onend = () => setIsListening(false);

      recognition.start();
    } catch (e) {
      console.info("Voice input handled:", e);
      setIsListening(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header Banner */}
      <div className="glass-card rounded-2xl p-6 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-amber-400 bg-amber-950/60 px-3 py-1 rounded-full border border-amber-800/50">
            Autonomous Turn-by-Turn Simulator
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white mt-2">
            AI Mock Interview Drill
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl">
            Simulate realistic technical and behavioral rounds. The AI agent listens or reads your answer, provides immediate score grading, and constructs polished model solutions.
          </p>
        </div>

        {hasStarted && !isFinished && (
          <button
            onClick={() => setHasStarted(false)}
            className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300 border border-slate-700 flex items-center gap-1.5 self-start md:self-center transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Setup</span>
          </button>
        )}
      </div>

      {/* Setup View (Before Interview Starts) */}
      {!hasStarted ? (
        <div className="glass-card rounded-3xl p-8 border border-slate-800 max-w-3xl mx-auto space-y-6">
          <div className="text-center max-w-md mx-auto space-y-2">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center mx-auto">
              <Mic className="w-6 h-6" />
            </div>
            <h2 className="text-xl font-bold text-white">Configure Your Mock Interview</h2>
            <p className="text-xs text-slate-400">
              Customize role difficulty to match your upcoming college placement or internship tests.
            </p>
          </div>

          <div className="space-y-4">
            {/* Career Selector */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Target Career Role</label>
              <select
                value={selectedCareer}
                onChange={e => setSelectedCareer(e.target.value)}
                className="w-full glass-input px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold bg-slate-900"
              >
                <option value="AI/ML Engineer">AI/ML Engineer</option>
                <option value="Full Stack Developer">Full Stack Developer</option>
                <option value="Data Scientist">Data Scientist</option>
                <option value="Backend Developer">Backend Developer</option>
              </select>
            </div>

            {/* Experience Level */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Experience Level</label>
              <select
                value={selectedExperience}
                onChange={e => setSelectedExperience(e.target.value)}
                className="w-full glass-input px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold bg-slate-900"
              >
                <option value="College Student / Fresher">College Student / Fresher (Semester 3-8)</option>
                <option value="Summer Intern Candidate">Summer Intern Candidate</option>
                <option value="Junior Engineer (0-1 yrs)">Junior Engineer (0-1 yrs)</option>
              </select>
            </div>

            {/* Difficulty Tier */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Difficulty Tier</label>
              <div className="grid grid-cols-3 gap-3">
                {['Foundational', 'Intermediate', 'Hard'].map((diff) => (
                  <button
                    key={diff}
                    type="button"
                    onClick={() => setSelectedDifficulty(diff)}
                    className={`py-2.5 px-3 rounded-xl text-xs font-bold border transition-all ${
                      selectedDifficulty === diff
                        ? 'bg-amber-500/20 text-amber-300 border-amber-500/50 shadow-sm'
                        : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                    }`}
                  >
                    {diff}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <button
            onClick={handleStartInterview}
            className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-600 via-orange-600 to-amber-700 hover:from-amber-500 hover:to-orange-500 text-white font-bold text-sm shadow-xl shadow-amber-600/25 flex items-center justify-center gap-2 transition-all hover:scale-[1.01]"
          >
            <Play className="w-4 h-4 fill-white" />
            <span>Begin Mock Interview Session</span>
          </button>
        </div>
      ) : isFinished ? (
        /* Finished Report Card */
        <div className="glass-card rounded-3xl p-8 border border-slate-800 text-center max-w-2xl mx-auto space-y-6">
          <div className="w-14 h-14 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto shadow-lg shadow-emerald-500/20">
            <Award className="w-8 h-8" />
          </div>
          <div>
            <h2 className="text-2xl font-extrabold text-white">Interview Session Completed!</h2>
            <p className="text-xs text-slate-400 mt-1">
              You completed 3 turn-by-turn questions for {selectedCareer}.
            </p>
          </div>

          {/* Average Score */}
          <div className="p-5 rounded-2xl bg-slate-950/80 border border-slate-800 max-w-xs mx-auto">
            <span className="text-xs text-slate-400 uppercase tracking-wider font-semibold">
              Composite Technical Grade
            </span>
            <div className="text-4xl font-extrabold text-emerald-400 font-mono my-1">
              {(completedSessions.reduce((a, b) => a + b, 0) / (completedSessions.length || 1)).toFixed(1)}
              <span className="text-lg text-slate-500 font-normal">/10</span>
            </div>
            <span className="text-xs text-emerald-300 font-medium">Strong Placement Probability</span>
          </div>

          <div className="flex justify-center gap-3">
            <button
              onClick={handleStartInterview}
              className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-all"
            >
              Start Another Round
            </button>
          </div>
        </div>
      ) : (
        /* Active Question & Answering View */
        <div className="space-y-6">
          {/* Question Banner */}
          <div className="glass-card rounded-2xl p-6 border border-slate-800 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <span className="font-mono text-xs font-bold px-2.5 py-1 rounded-md bg-amber-500/20 text-amber-300 border border-amber-500/40">
                  Question {questionIndex} of 3
                </span>
                <span className="text-xs text-slate-400 font-medium">
                  {currentQuestion?.category || 'Technical'} • {selectedDifficulty}
                </span>
              </div>

              <div className="flex items-center gap-2 font-mono text-xs text-slate-300 bg-slate-950 px-3 py-1 rounded-lg border border-slate-800">
                <Clock className="w-3.5 h-3.5 text-amber-400" />
                <span>{formatTimer(elapsedSeconds)}</span>
              </div>
            </div>

            <h2 className="text-base sm:text-xl font-bold text-white leading-snug">
              {currentQuestion?.question || 'Loading question...'}
            </h2>

            {/* Hint Accordion */}
            {currentQuestion?.hints && currentQuestion.hints.length > 0 && (
              <div>
                <button
                  onClick={() => setShowHints(!showHints)}
                  className="text-xs text-indigo-400 hover:text-indigo-300 font-semibold flex items-center gap-1"
                >
                  <HelpCircle className="w-3.5 h-3.5" />
                  <span>{showHints ? 'Hide Hints' : 'Show AI Hint'}</span>
                </button>
                {showHints && (
                  <div className="mt-2 p-3 rounded-xl bg-indigo-950/30 border border-indigo-800/40 text-xs text-indigo-200 space-y-1">
                    {currentQuestion.hints.map((h, idx) => (
                      <p key={idx}>• {h}</p>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Student Answer Box (when not yet evaluated) */}
          {!evaluation ? (
            <div className="glass-card rounded-2xl p-6 border border-slate-800 space-y-4">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                  <span>Your Answer</span>
                  {isListening && (
                    <span className="text-rose-400 text-xs font-semibold animate-pulse flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-rose-500" />
                      Listening to microphone...
                    </span>
                  )}
                </label>

                <button
                  type="button"
                  onClick={handleToggleVoice}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-all flex items-center gap-1.5 ${
                    isListening
                      ? 'bg-rose-600/30 text-rose-400 border-rose-500 animate-pulse'
                      : 'bg-slate-900 text-slate-300 hover:text-white border-slate-700'
                  }`}
                  title="Speak answer using Web Speech recognition"
                >
                  {isListening ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5 text-amber-400" />}
                  <span>{isListening ? 'Stop Mic' : 'Voice Dictate'}</span>
                </button>
              </div>

              <textarea
                rows={7}
                value={studentAnswer}
                onChange={e => setStudentAnswer(e.target.value)}
                placeholder="Type or dictate your technical explanation. Structure your points clearly with definitions, mechanisms, and real-world trade-offs..."
                className="w-full glass-input p-4 rounded-xl text-xs sm:text-sm leading-relaxed"
              />

              <div className="flex items-center justify-between pt-2">
                <span className="text-xs text-slate-500">
                  Agent Tool: <span className="font-mono text-slate-400">evaluate_interview_answer()</span>
                </span>

                <button
                  onClick={handleSubmitAnswer}
                  disabled={!studentAnswer.trim() || isSubmitting}
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white font-bold text-xs shadow-lg shadow-amber-600/25 flex items-center gap-1.5 transition-all disabled:opacity-50"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{isSubmitting ? 'AI is optimizing your request...' : 'Submit Answer for AI Grading'}</span>
                </button>
              </div>
            </div>
          ) : (
            /* Evaluation Results Card */
            <div className="glass-card rounded-2xl p-6 border border-slate-800 space-y-6 animate-in fade-in duration-300">
              {/* Score Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-amber-500/20 text-amber-300 font-mono font-extrabold text-xl flex items-center justify-center border border-amber-500/40">
                    {evaluation.score.toFixed(1)}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-400 uppercase">Verdict:</span>
                      <span className="text-sm font-bold text-white px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                        {evaluation.verdict}
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 mt-0.5">
                      Correctness Match: {evaluation.correctnessPercentage}%
                    </p>
                  </div>
                </div>

                <button
                  onClick={handleNextQuestion}
                  className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-lg transition-all"
                >
                  <span>{questionIndex >= 3 ? 'View Final Report' : 'Next Question'}</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>

              {/* Technical Feedback & Communication Feedback */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Technical Feedback */}
                <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-1.5">
                  <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Technical Assessment
                  </span>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {evaluation.technicalFeedback}
                  </p>
                </div>

                {/* Communication Feedback */}
                <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-1.5">
                  <span className="text-xs font-bold uppercase tracking-wider text-indigo-400 flex items-center gap-1.5">
                    <Zap className="w-3.5 h-3.5" />
                    Communication Structure & Clarity
                  </span>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {evaluation.communicationFeedback}
                  </p>
                </div>
              </div>

              {/* Polished Model Answer */}
              <div className="p-5 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2">
                <span className="text-xs font-bold uppercase tracking-wider text-purple-400 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" />
                  AI Suggested Improved / Ideal Answer (Model Solution)
                </span>
                <p className="text-xs sm:text-sm text-slate-200 font-serif leading-relaxed italic bg-slate-900/60 p-4 rounded-lg border border-slate-800">
                  "{evaluation.suggestedImprovedAnswer}"
                </p>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
