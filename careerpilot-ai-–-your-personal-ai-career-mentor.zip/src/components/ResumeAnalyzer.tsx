import React, { useState } from 'react';
import { 
  FileText, 
  Upload, 
  CheckCircle2, 
  AlertTriangle, 
  Sparkles, 
  Zap, 
  TrendingUp, 
  FileCode, 
  Layers, 
  RefreshCw, 
  ArrowRight, 
  Target, 
  ShieldCheck, 
  AlertCircle,
  Award
} from 'lucide-react';
import { ResumeAnalysisResult, StudentProfile } from '../types';
import { analyzeResume } from '../api/client';
import { DEMO_STUDENT, DEMO_RESUME_ANALYSIS } from '../data/demoData';
import { useAgentStatus } from '../context/AgentStatusContext';

interface ResumeAnalyzerProps {
  profile: StudentProfile;
  resumeAnalysis: ResumeAnalysisResult;
  setResumeAnalysis: React.Dispatch<React.SetStateAction<ResumeAnalysisResult>>;
}

export const ResumeAnalyzer: React.FC<ResumeAnalyzerProps> = ({
  profile,
  resumeAnalysis,
  setResumeAnalysis
}) => {
  const { reportThinking, reportReady, reportError } = useAgentStatus();
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [resumeTextInput, setResumeTextInput] = useState<string>(profile.resumeText || DEMO_STUDENT.resumeText || '');
  const [inputMode, setInputMode] = useState<'upload' | 'text'>('upload');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [targetRole, setTargetRole] = useState(profile.preferredCareer || 'AI/ML Engineer');
  const [dragActive, setDragActive] = useState(false);

  // File upload handler
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setSelectedFile(e.target.files[0]);
    }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      setSelectedFile(e.dataTransfer.files[0]);
    }
  };

  const handleRunAnalysis = async () => {
    setIsAnalyzing(true);
    reportThinking("AI is optimizing your request & parsing ATS competencies...");
    try {
      if (selectedFile) {
        // Convert to base64
        const reader = new FileReader();
        reader.readAsDataURL(selectedFile);
        reader.onload = async () => {
          try {
            const base64Content = (reader.result as string).split(',')[1];
            const result = await analyzeResume({
              pdfBase64: base64Content,
              fileName: selectedFile.name,
              targetRole
            });
            setResumeAnalysis(result);
            reportReady();
          } catch (err) {
            reportError("AI temporarily unavailable — Retry", handleRunAnalysis);
          } finally {
            setIsAnalyzing(false);
          }
        };
      } else {
        const result = await analyzeResume({
          resumeText: resumeTextInput,
          fileName: 'Student_Resume.pdf',
          targetRole
        });
        setResumeAnalysis(result);
        reportReady();
        setIsAnalyzing(false);
      }
    } catch (err) {
      console.info("Resume analysis handled:", err);
      reportError("AI temporarily unavailable — Retry", handleRunAnalysis);
      setIsAnalyzing(false);
    }
  };

  const handleLoadSampleResume = () => {
    setSelectedFile(null);
    setResumeTextInput(DEMO_STUDENT.resumeText || '');
    setResumeAnalysis(DEMO_RESUME_ANALYSIS);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header Banner */}
      <div className="glass-card rounded-2xl p-6 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-5">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 bg-emerald-950/60 px-3 py-1 rounded-full border border-emerald-800/50">
            Autonomous Resume Intelligence
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white mt-2">
            AI Resume Analyzer & ATS Audit
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl">
            Upload your college resume in PDF format. The agent performs keyword parsing, flags missing frameworks, and rewrites bullets with quantifiable impact.
          </p>
        </div>

        <button
          onClick={handleLoadSampleResume}
          className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 hover:border-emerald-500/50 flex items-center gap-2 transition-all shrink-0"
          title="Instant load Rahul's resume for competition testing"
        >
          <Zap className="w-4 h-4 text-emerald-400" />
          <span>Load Rahul's Sample Resume</span>
        </button>
      </div>

      {/* Upload / Input Section */}
      <div className="glass-card rounded-2xl p-6 border border-slate-800 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setInputMode('upload')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                inputMode === 'upload'
                  ? 'bg-indigo-600/30 text-indigo-300 border border-indigo-500/40'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              PDF Upload
            </button>
            <button
              onClick={() => setInputMode('text')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                inputMode === 'text'
                  ? 'bg-indigo-600/30 text-indigo-300 border border-indigo-500/40'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Paste Resume Text
            </button>
          </div>

          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-400">Target Role:</span>
            <input
              type="text"
              value={targetRole}
              onChange={(e) => setTargetRole(e.target.value)}
              className="glass-input px-3 py-1 rounded-lg text-xs font-semibold max-w-[200px]"
              placeholder="e.g. AI/ML Engineer"
            />
          </div>
        </div>

        {/* Upload Mode */}
        {inputMode === 'upload' ? (
          <div
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
            className={`border-2 border-dashed rounded-2xl p-8 text-center transition-all ${
              dragActive
                ? 'border-indigo-500 bg-indigo-950/20'
                : 'border-slate-700 bg-slate-950/40 hover:border-slate-600'
            }`}
          >
            <div className="w-12 h-12 rounded-2xl bg-indigo-600/20 text-indigo-400 flex items-center justify-center mx-auto mb-3">
              <Upload className="w-6 h-6" />
            </div>
            <h3 className="text-sm font-bold text-white mb-1">
              {selectedFile ? selectedFile.name : 'Upload your PDF resume'}
            </h3>
            <p className="text-xs text-slate-400 mb-4">
              Drag and drop your PDF here, or click to browse files
            </p>
            <label className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 border border-slate-700 cursor-pointer transition-colors">
              <span>Select PDF</span>
              <input
                type="file"
                accept=".pdf,application/pdf"
                onChange={handleFileChange}
                className="hidden"
              />
            </label>
            {selectedFile && (
              <div className="mt-3 text-xs text-emerald-400 font-medium">
                ✓ Ready for analysis ({Math.round(selectedFile.size / 1024)} KB)
              </div>
            )}
          </div>
        ) : (
          <div>
            <textarea
              rows={8}
              value={resumeTextInput}
              onChange={(e) => setResumeTextInput(e.target.value)}
              placeholder="Paste your plain text resume or project bullets here..."
              className="w-full glass-input p-4 rounded-xl text-xs font-mono leading-relaxed"
            />
          </div>
        )}

        <div className="flex items-center justify-between pt-2">
          <span className="text-xs text-slate-400">
            Powered by agent tool: <span className="font-mono text-slate-300">analyze_resume()</span>
          </span>
          <button
            onClick={handleRunAnalysis}
            disabled={isAnalyzing || (!selectedFile && !resumeTextInput.trim())}
            className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 flex items-center gap-2 transition-all disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isAnalyzing ? 'animate-spin' : ''}`} />
            <span>{isAnalyzing ? 'AI is optimizing your request...' : 'Analyze Resume'}</span>
          </button>
        </div>
      </div>

      {/* Analysis Results Display */}
      <div className="space-y-6">
        {/* Scores & ATS Compliance Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {/* Overall Score */}
          <div className="glass-card rounded-2xl p-5 border border-slate-800 text-center flex flex-col items-center justify-center">
            <span className="text-xs text-slate-400 uppercase tracking-wider font-semibold mb-1">
              Overall Technical Score
            </span>
            <div className="text-4xl font-extrabold text-white font-mono my-1">
              {resumeAnalysis.score}
              <span className="text-lg text-slate-500 font-normal">/100</span>
            </div>
            <span className="text-xs px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-medium">
              {resumeAnalysis.score >= 80 ? 'Placement Ready' : 'Competitive Candidate'}
            </span>
          </div>

          {/* ATS Score */}
          <div className="glass-card rounded-2xl p-5 border border-slate-800 text-center flex flex-col items-center justify-center">
            <span className="text-xs text-slate-400 uppercase tracking-wider font-semibold mb-1">
              ATS Readability Match
            </span>
            <div className="text-4xl font-extrabold text-emerald-400 font-mono my-1">
              {resumeAnalysis.atsScore}%
            </div>
            <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-medium">
              {resumeAnalysis.atsFeedback.formattingStatus} Formatting
            </span>
          </div>

          {/* Keyword Match */}
          <div className="glass-card rounded-2xl p-5 border border-slate-800 text-center flex flex-col items-center justify-center">
            <span className="text-xs text-slate-400 uppercase tracking-wider font-semibold mb-1">
              Role Keyword Density
            </span>
            <div className="text-4xl font-extrabold text-purple-300 font-mono my-1">
              {resumeAnalysis.atsFeedback.keywordMatchRate}%
            </div>
            <span className="text-xs text-slate-400">
              For target: {targetRole}
            </span>
          </div>

          {/* Action Verb Strength */}
          <div className="glass-card rounded-2xl p-5 border border-slate-800 text-center flex flex-col items-center justify-center">
            <span className="text-xs text-slate-400 uppercase tracking-wider font-semibold mb-1">
              Action Verb Impact
            </span>
            <div className="text-2xl font-extrabold text-amber-300 my-2">
              {resumeAnalysis.atsFeedback.actionVerbStrength}
            </div>
            <span className="text-xs text-slate-400">
              Quantifiable Impact Analysis
            </span>
          </div>
        </div>

        {/* Executive Summary */}
        <div className="glass-card rounded-2xl p-6 border border-slate-800">
          <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 mb-2 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-indigo-400" />
            Agent Executive Evaluation ({resumeAnalysis.fileName})
          </h3>
          <p className="text-xs sm:text-sm text-slate-200 leading-relaxed">
            {resumeAnalysis.summary}
          </p>
        </div>

        {/* Strengths & Weaknesses Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Strengths */}
          <div className="glass-card rounded-2xl p-6 border border-slate-800 space-y-3">
            <h3 className="text-sm font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-2 border-b border-slate-800 pb-3">
              <CheckCircle2 className="w-4 h-4" />
              Identified Strengths ({resumeAnalysis.strengths.length})
            </h3>
            <ul className="space-y-2.5">
              {resumeAnalysis.strengths.map((str, idx) => (
                <li key={idx} className="flex items-start gap-2.5 text-xs text-slate-300 leading-relaxed">
                  <span className="text-emerald-400 font-bold">✓</span>
                  <span>{str}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Weaknesses */}
          <div className="glass-card rounded-2xl p-6 border border-slate-800 space-y-3">
            <h3 className="text-sm font-bold text-amber-400 uppercase tracking-wider flex items-center gap-2 border-b border-slate-800 pb-3">
              <AlertTriangle className="w-4 h-4" />
              Critical Deficits to Fix ({resumeAnalysis.weaknesses.length})
            </h3>
            <ul className="space-y-2.5">
              {resumeAnalysis.weaknesses.map((weak, idx) => (
                <li key={idx} className="flex items-start gap-2.5 text-xs text-slate-300 leading-relaxed">
                  <span className="text-amber-400 font-bold">!</span>
                  <span>{weak}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Missing Essential Skills */}
        <div className="glass-card rounded-2xl p-6 border border-slate-800">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider mb-3 flex items-center gap-2">
            <Target className="w-4 h-4 text-rose-400" />
            Skills Recruiter Search Algorithms Are Looking For (Missing in Resume)
          </h3>
          <div className="flex flex-wrap gap-2">
            {resumeAnalysis.missingSkills.map((skill) => (
              <span
                key={skill}
                className="px-3 py-1 rounded-lg bg-rose-950/40 text-rose-300 border border-rose-800/40 text-xs font-mono font-medium"
              >
                + {skill}
              </span>
            ))}
          </div>
        </div>

        {/* Suggested Bullet-Point Improvements */}
        <div className="glass-card rounded-2xl p-6 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-400" />
              Action-Verb & Impact Bullet Rewrites
            </h3>
            <span className="text-xs text-slate-500">ATS Optimization Engine</span>
          </div>

          <div className="space-y-4">
            {resumeAnalysis.suggestedImprovements.map((imp, idx) => (
              <div key={idx} className="p-4 rounded-xl bg-slate-950/60 border border-slate-800/80 space-y-2.5">
                <span className="text-xs font-mono font-bold text-indigo-400">
                  {imp.section}
                </span>

                <div className="p-2.5 rounded-lg bg-rose-950/20 border border-rose-900/30 text-xs text-rose-300">
                  <span className="font-bold text-rose-400 block mb-0.5">Original Issue:</span>
                  {imp.currentIssue}
                </div>

                <div className="p-2.5 rounded-lg bg-emerald-950/20 border border-emerald-900/30 text-xs text-emerald-300">
                  <span className="font-bold text-emerald-400 block mb-0.5">AI Recommended Rewrite:</span>
                  "{imp.suggestedRevision}"
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recommended Resume Projects */}
        <div className="glass-card rounded-2xl p-6 border border-slate-800 space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Award className="w-4 h-4 text-purple-400" />
            Recommended Projects to Add to Resume
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {resumeAnalysis.recommendedProjects.map((p, idx) => (
              <div key={idx} className="p-4 rounded-xl bg-slate-950/60 border border-slate-800">
                <h4 className="text-xs sm:text-sm font-bold text-white mb-1">{p.name}</h4>
                <p className="text-xs text-slate-400 mb-3">{p.rationale}</p>
                <div className="flex flex-wrap gap-1">
                  {p.stack.map(s => (
                    <span key={s} className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-900 text-slate-300 border border-slate-800">
                      {s}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
