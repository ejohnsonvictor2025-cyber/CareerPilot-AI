import React, { useState } from 'react';
import { 
  Map, 
  CheckCircle2, 
  Clock, 
  BookOpen, 
  ExternalLink, 
  Sparkles, 
  ArrowRight, 
  ChevronDown, 
  ChevronUp, 
  Layers, 
  RefreshCw, 
  Award,
  Zap
} from 'lucide-react';
import { CareerRoadmap, RoadmapStep, StudentProfile } from '../types';
import { fetchRoadmap } from '../api/client';
import { useAgentStatus } from '../context/AgentStatusContext';

interface RoadmapViewProps {
  roadmap: CareerRoadmap;
  setRoadmap: React.Dispatch<React.SetStateAction<CareerRoadmap>>;
  profile: StudentProfile;
}

export const RoadmapView: React.FC<RoadmapViewProps> = ({
  roadmap,
  setRoadmap,
  profile
}) => {
  const { reportThinking, reportReady, reportError } = useAgentStatus();
  const [expandedStepId, setExpandedStepId] = useState<string>(roadmap.steps[1]?.id || roadmap.steps[0]?.id);
  const [isRegenerating, setIsRegenerating] = useState(false);
  const [selectedRole, setSelectedRole] = useState(roadmap.career || 'AI/ML Engineer');

  // Toggle task completion
  const handleToggleTask = (stepId: string, taskId: string) => {
    setRoadmap(prev => {
      const updatedSteps = prev.steps.map(step => {
        if (step.id !== stepId) return step;
        const updatedTasks = step.tasks.map(t => {
          if (t.id !== taskId) return t;
          return { ...t, completed: !t.completed };
        });

        // Update step status automatically
        const allCompleted = updatedTasks.every(t => t.completed);
        const someCompleted = updatedTasks.some(t => t.completed);
        let newStatus: RoadmapStep['status'] = step.status;
        if (allCompleted) newStatus = 'completed';
        else if (someCompleted) newStatus = 'in-progress';

        return {
          ...step,
          tasks: updatedTasks,
          status: newStatus
        };
      });

      return {
        ...prev,
        steps: updatedSteps
      };
    });
  };

  const handleRegenerateRoadmap = async () => {
    setIsRegenerating(true);
    reportThinking("AI is optimizing your career roadmap & milestones...");
    try {
      const newRoadmap = await fetchRoadmap(selectedRole, profile.currentSkills);
      setRoadmap(newRoadmap);
      if (newRoadmap.steps.length > 0) {
        setExpandedStepId(newRoadmap.steps[0].id);
      }
      reportReady();
    } catch (err) {
      console.info("Roadmap fetch handled:", err);
      reportError("AI temporarily unavailable — Retry", handleRegenerateRoadmap);
    } finally {
      setIsRegenerating(false);
    }
  };

  // Calculate overall task stats
  const allTasks = roadmap.steps.flatMap(s => s.tasks);
  const completedTasks = allTasks.filter(t => t.completed).length;
  const totalTasks = allTasks.length || 1;
  const progressPct = Math.round((completedTasks / totalTasks) * 100);

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header Banner */}
      <div className="glass-card rounded-2xl p-6 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-5">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-purple-400 bg-purple-950/60 px-3 py-1 rounded-full border border-purple-800/50">
            Interactive Semester Curriculum
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white mt-2">
            {roadmap.career} Roadmap
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl">
            {roadmap.description}
          </p>
        </div>

        {/* Controls */}
        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          <select
            value={selectedRole}
            onChange={(e) => setSelectedRole(e.target.value)}
            className="glass-input px-3 py-2 rounded-xl text-xs font-semibold bg-slate-900"
          >
            <option value="AI/ML Engineer">AI/ML Engineer</option>
            <option value="Full Stack Developer">Full Stack Developer</option>
            <option value="Data Scientist">Data Scientist</option>
            <option value="DevOps / Cloud Engineer">DevOps / Cloud Engineer</option>
          </select>

          <button
            onClick={handleRegenerateRoadmap}
            disabled={isRegenerating}
            className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold shadow-lg shadow-purple-600/25 flex items-center gap-1.5 transition-all disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRegenerating ? 'animate-spin' : ''}`} />
            <span>{isRegenerating ? 'AI is optimizing your request...' : 'Regenerate with AI'}</span>
          </button>
        </div>
      </div>

      {/* Progress & Milestone Chain Bar */}
      <div className="glass-card rounded-2xl p-6 border border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <div className="text-xs font-bold text-white flex items-center gap-2">
              <span>Overall Roadmap Progress: {progressPct}%</span>
              <span className="text-[11px] font-normal text-slate-400">
                ({completedTasks} of {totalTasks} tasks completed)
              </span>
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">
              Estimated Total Duration: {roadmap.totalEstimatedWeeks} Weeks (Semester Paced)
            </div>
          </div>

          <div className="text-xs font-mono font-bold text-indigo-400">
            {roadmap.steps.filter(s => s.status === 'completed').length} / {roadmap.steps.length} Milestones Cleared
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-slate-950 h-3 rounded-full overflow-hidden border border-slate-800">
          <div
            className="h-full bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500 rounded-full transition-all duration-500"
            style={{ width: `${progressPct}%` }}
          />
        </div>

        {/* Horizontal Milestone Connector Chain (Visual Chain) */}
        <div className="pt-3 overflow-x-auto pb-2">
          <div className="flex items-center min-w-max gap-2 text-xs font-medium">
            {roadmap.steps.map((step, idx) => {
              const isDone = step.status === 'completed';
              const isCurrent = step.status === 'in-progress';
              return (
                <React.Fragment key={step.id}>
                  <button
                    onClick={() => setExpandedStepId(step.id)}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border transition-all ${
                      expandedStepId === step.id
                        ? 'bg-purple-950/70 border-purple-500 text-purple-200 shadow-sm'
                        : isDone
                        ? 'bg-emerald-950/40 border-emerald-800/60 text-emerald-300'
                        : isCurrent
                        ? 'bg-indigo-950/40 border-indigo-500/50 text-indigo-300'
                        : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
                    }`}
                  >
                    {isDone ? (
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <span className="w-3.5 h-3.5 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-[9px] font-mono">
                        {idx + 1}
                      </span>
                    )}
                    <span className="font-semibold">{step.title.split(' ')[0]}</span>
                  </button>
                  {idx < roadmap.steps.length - 1 && (
                    <ArrowRight className="w-3.5 h-3.5 text-slate-600 shrink-0" />
                  )}
                </React.Fragment>
              );
            })}
          </div>
        </div>
      </div>

      {/* Step Cards Accordion List */}
      <div className="space-y-4">
        {roadmap.steps.map((step, idx) => {
          const isExpanded = expandedStepId === step.id;
          const isDone = step.status === 'completed';
          const isCurrent = step.status === 'in-progress';

          return (
            <div
              key={step.id}
              className={`glass-card rounded-2xl border transition-all overflow-hidden ${
                isExpanded ? 'border-purple-500/50 shadow-lg shadow-purple-950/30' : 'border-slate-800'
              }`}
            >
              {/* Step Header */}
              <div
                onClick={() => setExpandedStepId(isExpanded ? '' : step.id)}
                className="p-5 flex items-center justify-between cursor-pointer hover:bg-slate-900/40 transition-colors"
              >
                <div className="flex items-center gap-4">
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center font-mono font-bold text-xs shrink-0 ${
                      isDone
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                        : isCurrent
                        ? 'bg-indigo-500/20 text-indigo-400 border border-indigo-500/40'
                        : 'bg-slate-800 text-slate-400 border border-slate-700'
                    }`}
                  >
                    {isDone ? <CheckCircle2 className="w-5 h-5" /> : `0${idx + 1}`}
                  </div>

                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-sm sm:text-base font-bold text-white">
                        {step.title}
                      </h3>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700 hidden sm:inline">
                        {step.category}
                      </span>
                    </div>
                    <div className="flex items-center gap-3 text-xs text-slate-400 mt-0.5">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3 text-slate-500" />
                        {step.estimatedTime}
                      </span>
                      <span>•</span>
                      <span className="text-slate-400">
                        {step.tasks.filter(t => t.completed).length}/{step.tasks.length} tasks completed
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <span
                    className={`text-xs font-semibold px-2.5 py-1 rounded-full uppercase tracking-wider text-[10px] ${
                      isDone
                        ? 'bg-emerald-950/60 text-emerald-300 border border-emerald-800/40'
                        : isCurrent
                        ? 'bg-indigo-950/60 text-indigo-300 border border-indigo-800/40'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {step.status}
                  </span>
                  {isExpanded ? (
                    <ChevronUp className="w-5 h-5 text-slate-400" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-slate-400" />
                  )}
                </div>
              </div>

              {/* Step Expanded Content */}
              {isExpanded && (
                <div className="px-5 pb-6 pt-2 border-t border-slate-800/80 space-y-5 bg-slate-950/30">
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                    {step.description}
                  </p>

                  {/* Checkable Tasks */}
                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2 flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-indigo-400" />
                      Milestone Action Checklist (Click to complete)
                    </h4>
                    <div className="space-y-2">
                      {step.tasks.map((task) => (
                        <label
                          key={task.id}
                          className="flex items-start gap-3 p-3 rounded-xl bg-slate-900/60 border border-slate-800/80 hover:border-slate-700 cursor-pointer transition-colors select-none"
                        >
                          <input
                            type="checkbox"
                            checked={task.completed}
                            onChange={() => handleToggleTask(step.id, task.id)}
                            className="mt-0.5 w-4 h-4 rounded text-indigo-600 bg-slate-950 border-slate-700 focus:ring-indigo-500 focus:ring-offset-slate-900 cursor-pointer"
                          />
                          <span
                            className={`text-xs sm:text-sm ${
                              task.completed
                                ? 'line-through text-slate-500'
                                : 'text-slate-200 font-medium'
                            }`}
                          >
                            {task.title}
                          </span>
                        </label>
                      ))}
                    </div>
                  </div>

                  {/* Skills Acquired & Recommended Resources */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                    {/* Skills Acquired */}
                    <div className="p-4 rounded-xl bg-slate-900/40 border border-slate-800">
                      <span className="text-xs font-bold text-slate-300 block mb-2">
                        Competencies Acquired:
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {step.skillsAcquired.map(skill => (
                          <span
                            key={skill}
                            className="text-xs px-2.5 py-0.5 rounded-md bg-purple-950/50 text-purple-300 border border-purple-800/40 font-mono"
                          >
                            {skill}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* Resources */}
                    <div className="p-4 rounded-xl bg-slate-900/40 border border-slate-800">
                      <span className="text-xs font-bold text-slate-300 block mb-2 flex items-center gap-1.5">
                        <BookOpen className="w-3.5 h-3.5 text-indigo-400" />
                        Curated Learning Resources:
                      </span>
                      <ul className="space-y-1.5 text-xs text-slate-300">
                        {step.recommendedResources.map((res, rIdx) => (
                          <li key={rIdx} className="flex items-center justify-between">
                            <span className="truncate pr-2">• {res.name}</span>
                            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-400 shrink-0">
                              {res.type}
                            </span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
