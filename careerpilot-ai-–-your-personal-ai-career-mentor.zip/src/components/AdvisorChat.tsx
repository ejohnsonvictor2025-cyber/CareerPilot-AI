import React, { useState, useRef, useEffect } from 'react';
import { 
  Bot, 
  User, 
  Send, 
  Sparkles, 
  Cpu, 
  Terminal, 
  CheckCircle2, 
  ArrowRight, 
  Layers, 
  Target, 
  Code2, 
  Mic, 
  MicOff, 
  RefreshCw,
  Zap,
  Info
} from 'lucide-react';
import { StudentProfile, AgentChatMessage, CareerRecommendation } from '../types';
import { sendAgentChat } from '../api/client';
import { useAgentStatus } from '../context/AgentStatusContext';

interface AdvisorChatProps {
  profile: StudentProfile;
  onOpenAgentModal: () => void;
}

const SAMPLE_QUESTIONS = [
  "I know Python and SQL and I'm interested in AI. What career should I choose?",
  "What are my primary skill gaps for landing an AI/ML Engineer internship?",
  "Recommend 3 standout portfolio projects using PyTorch and FastAPI.",
  "How should a 2nd-year CSE student balance data structures and machine learning?"
];

export const AdvisorChat: React.FC<AdvisorChatProps> = ({ profile, onOpenAgentModal }) => {
  const { reportThinking, reportReady, reportError } = useAgentStatus();
  const [messages, setMessages] = useState<AgentChatMessage[]>([
    {
      id: 'welcome-msg',
      sender: 'agent',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      text: `Hello **${profile.name}**! I am your autonomous **CareerPilot AI Agent**. 

I have indexed your academic context:
• **Academic Status**: ${profile.degree} (${profile.branch}), ${profile.year}
• **Verified Skills**: ${profile.currentSkills.join(', ') || 'None declared'}
• **Career Goal**: ${profile.careerGoal}

Ask me anything about role recommendations, skill-gap analysis, project ideation, or interview readiness!`,
      toolInvocations: [
        {
          toolName: 'analyze_student_profile',
          input: { student: profile.name, degree: profile.degree, skills: profile.currentSkills },
          status: 'completed',
          summary: `Loaded ${profile.name}'s profile vector into agent working memory.`
        }
      ]
    }
  ]);

  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handleSendMessage = async (textToSend?: string) => {
    const query = (textToSend || inputText).trim();
    if (!query || isLoading) return;

    const userMessage: AgentChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      text: query
    };

    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setIsLoading(true);
    reportThinking("AI Agent is selecting the best available model & optimizing your request...");

    try {
      const response = await sendAgentChat(query, profile, messages);

      const agentMessage: AgentChatMessage = {
        id: `agent-${Date.now()}`,
        sender: 'agent',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        text: response.text,
        toolInvocations: response.toolInvocations,
        recommendation: response.recommendation
      };

      setMessages(prev => [...prev, agentMessage]);
      reportReady();
    } catch (err: any) {
      const errorMessage: AgentChatMessage = {
        id: `err-${Date.now()}`,
        sender: 'agent',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        text: `I encountered a momentary agent synchronization issue. Please retry or click one of the suggested competition prompts above.`
      };
      setMessages(prev => [...prev, errorMessage]);
      reportError("AI temporarily unavailable — Retry", () => handleSendMessage(query));
    } finally {
      setIsLoading(false);
    }
  };

  // Speech Recognition support
  const handleToggleVoice = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert("Speech recognition is not supported in this browser. Please use keyboard input.");
      return;
    }

    if (isListening) {
      setIsListening(false);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'en-US';

      recognition.onstart = () => setIsListening(true);
      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInputText(prev => (prev ? `${prev} ${transcript}` : transcript));
        setIsListening(false);
      };
      recognition.onerror = () => setIsListening(false);
      recognition.onend = () => setIsListening(false);

      recognition.start();
    } catch (e) {
      console.info("Speech recognition handled:", e);
      setIsListening(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Header Banner */}
      <div className="glass-card rounded-2xl p-5 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-indigo-600/30">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg sm:text-xl font-extrabold text-white">
                AI Career Advisor Agent
              </h1>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                Live Tool Calling
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Autonomous reasoning over student competencies with function dispatching
            </p>
          </div>
        </div>

        <button
          onClick={onOpenAgentModal}
          className="self-start sm:self-center px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-purple-300 border border-slate-700 hover:border-purple-500/50 flex items-center gap-1.5 transition-all"
        >
          <Cpu className="w-3.5 h-3.5" />
          <span>View Agent Flow</span>
        </button>
      </div>

      {/* Suggested Quick Prompts */}
      <div className="space-y-1.5">
        <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
          <Sparkles className="w-3 h-3 text-indigo-400" />
          Quick Competition Prompts (Click to Ask)
        </span>
        <div className="flex flex-wrap gap-2">
          {SAMPLE_QUESTIONS.map((q, idx) => (
            <button
              key={idx}
              onClick={() => handleSendMessage(q)}
              disabled={isLoading}
              className="text-xs px-3 py-1.5 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 hover:border-indigo-500/50 text-left transition-all max-w-full truncate"
            >
              {q}
            </button>
          ))}
        </div>
      </div>

      {/* Chat Messages Container */}
      <div className="glass-card rounded-2xl border border-slate-800 overflow-hidden flex flex-col h-[560px]">
        <div className="flex-1 p-5 overflow-y-auto space-y-5">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex items-start gap-3 ${msg.sender === 'user' ? 'flex-row-reverse' : ''}`}
            >
              {/* Avatar */}
              <div
                className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 text-xs font-bold ${
                  msg.sender === 'user'
                    ? 'bg-blue-600 text-white'
                    : 'bg-gradient-to-tr from-indigo-600 to-purple-600 text-white shadow-md shadow-indigo-600/30'
                }`}
              >
                {msg.sender === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
              </div>

              {/* Message Bubble */}
              <div className={`space-y-2 max-w-[85%] sm:max-w-[75%] ${msg.sender === 'user' ? 'items-end' : ''}`}>
                {/* Tool Invocations Badge if agent invoked tools */}
                {msg.toolInvocations && msg.toolInvocations.length > 0 && (
                  <div className="space-y-1">
                    {msg.toolInvocations.map((tool, tIdx) => (
                      <div
                        key={tIdx}
                        className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-purple-950/70 text-purple-300 border border-purple-800/50 text-[11px] font-mono shadow-sm"
                      >
                        <Zap className="w-3 h-3 text-purple-400 animate-pulse" />
                        <span className="font-bold">Tool Executed:</span>
                        <span className="text-white">{tool.toolName}()</span>
                        {tool.summary && (
                          <span className="text-slate-400 font-sans text-[10px] hidden sm:inline">
                            — {tool.summary}
                          </span>
                        )}
                      </div>
                    ))}
                  </div>
                )}

                <div
                  className={`rounded-2xl p-4 text-xs sm:text-sm leading-relaxed ${
                    msg.sender === 'user'
                      ? 'bg-blue-600 text-white rounded-tr-none'
                      : 'bg-slate-900/90 text-slate-200 border border-slate-800 rounded-tl-none'
                  }`}
                >
                  <div className="whitespace-pre-wrap">{msg.text}</div>

                  {/* If the message returned a structured recommendation card */}
                  {msg.recommendation && (
                    <div className="mt-4 pt-4 border-t border-slate-800 space-y-4">
                      <div className="flex items-center justify-between bg-slate-950/80 p-3 rounded-xl border border-indigo-500/30">
                        <div className="flex items-center gap-2">
                          <Target className="w-4 h-4 text-indigo-400" />
                          <span className="font-bold text-white text-sm">
                            {msg.recommendation.recommendedCareer}
                          </span>
                        </div>
                        <span className="font-mono text-xs font-extrabold px-2.5 py-1 rounded-full bg-indigo-600/30 text-indigo-300 border border-indigo-500/40">
                          {msg.recommendation.matchPercentage}% Match
                        </span>
                      </div>

                      {/* Required vs Current vs Missing Skills */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                        <div className="p-3 rounded-xl bg-slate-950/50 border border-slate-800">
                          <span className="font-bold text-emerald-400 block mb-1.5 flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3" />
                            Current Skill Strengths
                          </span>
                          <div className="flex flex-wrap gap-1">
                            {msg.recommendation.currentSkillStrengths.map(s => (
                              <span key={s} className="px-2 py-0.5 rounded bg-emerald-950/60 text-emerald-300 border border-emerald-800/40 text-[11px]">
                                {s}
                              </span>
                            ))}
                          </div>
                        </div>

                        <div className="p-3 rounded-xl bg-slate-950/50 border border-slate-800">
                          <span className="font-bold text-amber-400 block mb-1.5 flex items-center gap-1">
                            <Zap className="w-3 h-3" />
                            Missing Skills to Learn
                          </span>
                          <div className="flex flex-wrap gap-1">
                            {msg.recommendation.missingSkills.map(s => (
                              <span key={s} className="px-2 py-0.5 rounded bg-amber-950/60 text-amber-300 border border-amber-800/40 text-[11px]">
                                {s}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>

                      {/* Recommended Projects */}
                      {msg.recommendation.recommendedProjects && msg.recommendation.recommendedProjects.length > 0 && (
                        <div className="space-y-2">
                          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block">
                            Recommended Projects for College Portfolio:
                          </span>
                          <div className="space-y-2">
                            {msg.recommendation.recommendedProjects.map((p, pIdx) => (
                              <div key={pIdx} className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800">
                                <div className="flex items-center justify-between text-xs font-bold text-slate-100">
                                  <span>{p.title}</span>
                                  <span className="text-[10px] text-indigo-400">{p.difficulty}</span>
                                </div>
                                <p className="text-[11px] text-slate-400 mt-0.5">{p.description}</p>
                                <div className="flex flex-wrap gap-1 mt-1.5">
                                  {p.techStack.map(t => (
                                    <span key={t} className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-slate-900 text-slate-300 border border-slate-800">
                                      {t}
                                    </span>
                                  ))}
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                <div className="text-[10px] text-slate-500 px-1">
                  {msg.timestamp}
                </div>
              </div>
            </div>
          ))}

          {/* Loading Indicator */}
          {isLoading && (
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-indigo-600 to-purple-600 flex items-center justify-center text-white text-xs shadow-md shadow-indigo-500/20">
                <Bot className="w-4 h-4" />
              </div>
              <div className="p-3.5 rounded-2xl rounded-tl-none bg-slate-900 border border-slate-800 text-xs text-slate-300 flex flex-col gap-1.5 shadow-lg">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-indigo-400 animate-pulse" />
                  <span className="text-indigo-300 font-bold text-xs">◉ Agent Thinking...</span>
                </div>
                <span className="text-slate-400 font-medium text-[11px]">
                  AI is optimizing your request & selecting the best available model...
                </span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input Bar */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/80">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center gap-2"
          >
            {/* Voice Dictation Button */}
            <button
              type="button"
              onClick={handleToggleVoice}
              className={`p-2.5 rounded-xl border transition-all ${
                isListening
                  ? 'bg-rose-600/30 text-rose-400 border-rose-500/50 animate-pulse'
                  : 'bg-slate-900 text-slate-400 hover:text-white border-slate-800 hover:bg-slate-800'
              }`}
              title={isListening ? 'Listening... click to stop' : 'Click to speak question'}
            >
              {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            </button>

            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder={`Ask CareerPilot AI (e.g. "I know Python & SQL, what career should I choose?")...`}
              disabled={isLoading}
              className="flex-1 glass-input px-4 py-2.5 rounded-xl text-xs sm:text-sm"
            />

            <button
              type="submit"
              disabled={!inputText.trim() || isLoading}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-xs shadow-md shadow-indigo-600/25 flex items-center gap-1.5 transition-all disabled:opacity-40"
            >
              <span>Send</span>
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
