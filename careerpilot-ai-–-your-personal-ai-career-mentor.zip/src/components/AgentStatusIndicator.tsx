import React from 'react';
import { useAgentStatus } from '../context/AgentStatusContext';
import { Check, AlertTriangle } from 'lucide-react';

interface AgentStatusIndicatorProps {
  showSubtext?: boolean;
  className?: string;
}

export const AgentStatusIndicator: React.FC<AgentStatusIndicatorProps> = ({ 
  showSubtext = false,
  className = '' 
}) => {
  const { status, subMessage, reportOnline, retryAction } = useAgentStatus();

  const handleRetryClick = () => {
    if (retryAction) {
      retryAction();
    } else {
      reportOnline();
    }
  };

  return (
    <div className={`flex flex-col items-start ${className}`}>
      {status === 'online' && (
        <div 
          id="agent-status-indicator"
          className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-semibold select-none shadow-sm transition-all"
          title="CareerPilot AI Agent is active and connected"
        >
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shadow-sm shadow-emerald-400/50" />
          <span className="whitespace-nowrap">● Agent Online</span>
        </div>
      )}

      {status === 'thinking' && (
        <div 
          id="agent-status-indicator"
          className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-indigo-500/15 border border-indigo-500/40 text-indigo-200 text-xs font-semibold select-none shadow-sm shadow-indigo-500/20 transition-all"
          title={subMessage || "AI Agent is selecting the best available model..."}
        >
          <span className="relative flex h-2.5 w-2.5 shrink-0">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-indigo-500"></span>
          </span>
          <span className="whitespace-nowrap animate-pulse font-bold">◉ Agent Thinking...</span>
        </div>
      )}

      {status === 'ready' && (
        <div 
          id="agent-status-indicator"
          className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-teal-500/15 border border-teal-500/40 text-teal-200 text-xs font-semibold select-none shadow-sm transition-all"
          title="Operation completed successfully"
        >
          <Check className="w-3.5 h-3.5 text-teal-400 shrink-0" />
          <span className="whitespace-nowrap font-bold">✓ Agent Ready</span>
        </div>
      )}

      {status === 'error' && (
        <button
          id="agent-status-indicator"
          type="button"
          onClick={handleRetryClick}
          className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/40 hover:border-amber-400 text-amber-300 text-xs font-semibold cursor-pointer shadow-sm transition-all active:scale-95"
          title="Click to retry request"
        >
          <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
          <span className="whitespace-nowrap font-bold">⚠ AI temporarily unavailable — Retry</span>
        </button>
      )}

      {showSubtext && status === 'thinking' && (
        <p className="text-[11px] text-indigo-300/80 mt-1 font-medium italic">
          {subMessage || "AI Agent is selecting the best available model..."}
        </p>
      )}
    </div>
  );
};
