import React from 'react';
import { 
  Compass, 
  Sparkles, 
  ArrowRight, 
  Bot, 
  FileText, 
  Map, 
  Mic, 
  ShieldCheck, 
  Target, 
  TrendingUp, 
  Award, 
  CheckCircle2, 
  Cpu, 
  Workflow, 
  GraduationCap, 
  Zap,
  Code2,
  Users,
  ChevronRight
} from 'lucide-react';
import { ActiveTab } from '../types';

interface LandingPageProps {
  onNavigate: (tab: ActiveTab) => void;
  onEnableDemo: () => void;
  onOpenAgentModal: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onNavigate,
  onEnableDemo,
  onOpenAgentModal
}) => {
  const featureCards = [
    {
      tab: 'advisor' as ActiveTab,
      title: 'AI Career Advisor',
      tagline: 'Autonomous Contextual Guidance',
      desc: 'Chat directly with an AI agent that maps your coursework, programming languages, and tech aspirations into precise role matches with quantifiable affinity percentages.',
      icon: Bot,
      accent: 'from-blue-500/20 to-indigo-500/20 border-blue-500/30 text-blue-400',
      badge: 'Reasoning Agent'
    },
    {
      tab: 'resume' as ActiveTab,
      title: 'Resume Analyzer',
      tagline: 'Deep ATS & Project Audit',
      desc: 'Upload your PDF resume. The agent parses ATS readability, audits technical project bullets, flags missing frameworks, and provides rewritten impact-driven bullet points.',
      icon: FileText,
      accent: 'from-purple-500/20 to-pink-500/20 border-purple-500/30 text-purple-400',
      badge: 'ATS Scanner'
    },
    {
      tab: 'roadmap' as ActiveTab,
      title: 'Skill Gap Analysis',
      tagline: 'Enterprise Readiness Matrix',
      desc: 'Examine exactly where your current technical skills stand against production industry requirements. Discover which math, backend, or cloud competencies you need next.',
      icon: Target,
      accent: 'from-emerald-500/20 to-teal-500/20 border-emerald-500/30 text-emerald-400',
      badge: 'Gap Matrix'
    },
    {
      tab: 'interview' as ActiveTab,
      title: 'AI Mock Interview',
      tagline: 'Voice & Turn-by-Turn Drills',
      desc: 'Simulate realistic technical and behavioral interviews one question at a time. Receive instantaneous scoring on technical depth, communication clarity, and ideal model answers.',
      icon: Mic,
      accent: 'from-amber-500/20 to-orange-500/20 border-amber-500/30 text-amber-400',
      badge: 'Turn-by-Turn Drill'
    }
  ];

  const benefits = [
    {
      icon: GraduationCap,
      title: 'Tailored for College Timelines',
      desc: 'Whether you are in your 1st year exploring or your 4th year targeting campus placements, the agent personalizes milestone difficulty to your semester.'
    },
    {
      icon: Code2,
      title: 'Portfolio-Grade Project Ideas',
      desc: 'Replaces generic tutorial projects with distinctive, resume-boosting full-stack and ML projects featuring Docker, RAG, and FastAPI.'
    },
    {
      icon: Zap,
      title: 'Autonomous Tool Dispatch',
      desc: 'Not a basic prompt wrapper—uses explicit logical tools (analyze_student_profile, evaluate_interview_answer) with transparent execution traces.'
    },
    {
      icon: TrendingUp,
      title: 'Measurable Skill Progression',
      desc: 'Track your roadmap tasks, resume audit scores, and mock interview grades in one consolidated, actionable dashboard.'
    }
  ];

  return (
    <div className="relative min-h-screen bg-mesh overflow-hidden">
      {/* Subtle background ambient glows */}
      <div className="absolute top-20 left-1/2 -translate-x-1/2 w-[800px] h-[350px] bg-gradient-to-tr from-indigo-600/15 via-purple-600/15 to-blue-600/15 blur-[120px] pointer-events-none rounded-full" />

      {/* Hero Section */}
      <section className="relative pt-12 pb-20 md:pt-20 md:pb-28 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        {/* Competition Badge */}
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-900/80 border border-slate-700/80 text-slate-300 text-xs font-semibold shadow-lg shadow-indigo-950/40 mb-8 hover:border-indigo-500/50 transition-colors">
          <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
          <span>College AI Project Competition Edition</span>
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
          <span className="text-emerald-300 font-mono text-[11px]">Gemini 3.7 Agent Engine</span>
        </div>

        {/* Hero Title */}
        <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold text-white tracking-tight leading-[1.1] max-w-5xl mx-auto">
          Your AI-Powered <br className="hidden sm:inline" />
          <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-400 via-indigo-300 to-purple-400">
            Career Mentor
          </span>
        </h1>

        {/* Hero Subtitle */}
        <p className="mt-6 text-base sm:text-xl text-slate-300 max-w-3xl mx-auto leading-relaxed font-normal">
          CareerPilot AI empowers college engineering students to discover high-match careers, 
          close technical skill gaps with interactive roadmaps, optimize resumes for ATS, 
          and master technical interviews with an autonomous reasoning AI agent.
        </p>

        {/* Hero Call to Action Buttons */}
        <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4 max-w-md mx-auto">
          <button
            onClick={() => onNavigate('dashboard')}
            className="w-full sm:w-auto px-7 py-3.5 rounded-xl bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white font-bold text-sm shadow-xl shadow-indigo-600/30 flex items-center justify-center gap-2 group transition-all hover:scale-[1.02]"
          >
            <span>Get Started Free</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>

          <button
            onClick={onEnableDemo}
            className="w-full sm:w-auto px-6 py-3.5 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-slate-200 hover:text-white font-bold text-sm border border-slate-700 hover:border-emerald-500/50 flex items-center justify-center gap-2 transition-all shadow-lg"
            title="Preloads sample 2nd Year CSE student (Rahul) for competition judging"
          >
            <Zap className="w-4 h-4 text-emerald-400" />
            <span>Load Demo (Rahul - 2nd Yr)</span>
          </button>
        </div>

        {/* Quick Highlights Bar */}
        <div className="mt-14 pt-8 border-t border-slate-800/80 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto text-left">
          <div className="p-3.5 rounded-xl bg-slate-900/40 border border-slate-800/60">
            <div className="text-xl sm:text-2xl font-extrabold text-white font-mono">86%</div>
            <div className="text-xs text-slate-400 mt-0.5">Average Career Match Precision</div>
          </div>
          <div className="p-3.5 rounded-xl bg-slate-900/40 border border-slate-800/60">
            <div className="text-xl sm:text-2xl font-extrabold text-indigo-400 font-mono">7+</div>
            <div className="text-xs text-slate-400 mt-0.5">Autonomous Agent Tools</div>
          </div>
          <div className="p-3.5 rounded-xl bg-slate-900/40 border border-slate-800/60">
            <div className="text-xl sm:text-2xl font-extrabold text-purple-400 font-mono">100%</div>
            <div className="text-xs text-slate-400 mt-0.5">Personalized Roadmaps</div>
          </div>
          <div className="p-3.5 rounded-xl bg-slate-900/40 border border-slate-800/60">
            <div className="text-xl sm:text-2xl font-extrabold text-emerald-400 font-mono">Turn-by-Turn</div>
            <div className="text-xs text-slate-400 mt-0.5">Live Mock Interview Drills</div>
          </div>
        </div>
      </section>

      {/* Feature Cards Section */}
      <section className="py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <span className="text-xs font-bold uppercase tracking-wider text-indigo-400 bg-indigo-950/60 px-3 py-1 rounded-full border border-indigo-800/50">
            Core Modules
          </span>
          <h2 className="mt-3 text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Engineered for Modern College Placements
          </h2>
          <p className="mt-3 text-sm sm:text-base text-slate-400">
            Every feature connects back to the autonomous AI Career Agent with real-time feedback loops.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {featureCards.map((feat) => {
            const Icon = feat.icon;
            return (
              <div
                key={feat.title}
                onClick={() => onNavigate(feat.tab)}
                className="glass-card-hover rounded-2xl p-7 flex flex-col justify-between cursor-pointer group"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className={`p-3 rounded-xl bg-gradient-to-br ${feat.accent} border`}>
                      <Icon className="w-6 h-6" />
                    </div>
                    <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                      {feat.badge}
                    </span>
                  </div>
                  <h3 className="text-xl font-bold text-white group-hover:text-indigo-300 transition-colors">
                    {feat.title}
                  </h3>
                  <div className="text-xs font-medium text-indigo-400/90 mt-1 mb-3">
                    {feat.tagline}
                  </div>
                  <p className="text-sm text-slate-400 leading-relaxed">
                    {feat.desc}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-slate-800/80 flex items-center justify-between text-xs font-semibold text-indigo-400 group-hover:text-indigo-300">
                  <span>Launch Module</span>
                  <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* How the AI Agent Works (Agent Architecture Blueprint) */}
      <section className="py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="glass-card rounded-3xl p-8 sm:p-12 border border-slate-800 relative overflow-hidden">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <span className="text-xs font-bold uppercase tracking-wider text-purple-400 bg-purple-950/60 px-3 py-1 rounded-full border border-purple-800/50">
              Agent Workflow
            </span>
            <h2 className="mt-3 text-3xl font-extrabold text-white">
              How the AI Agent Works
            </h2>
            <p className="mt-2 text-sm text-slate-400">
              A high-precision cyclical pipeline: User → AI Agent Brain → Reasoning/Planning → Specialized Tools → Personalized Result
            </p>
          </div>

          {/* Architecture Flow Diagram */}
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4 relative">
            <div className="p-5 rounded-2xl bg-slate-950/70 border border-slate-800 text-center flex flex-col items-center">
              <div className="w-10 h-10 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center mb-3">
                <Users className="w-5 h-5" />
              </div>
              <span className="text-[11px] font-mono text-slate-500 uppercase font-bold">Step 1</span>
              <h4 className="text-sm font-bold text-white mt-1">Student Input</h4>
              <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
                Profile, coursework, target goals & questions.
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-slate-950/70 border border-indigo-500/40 text-center flex flex-col items-center shadow-lg shadow-indigo-950/40">
              <div className="w-10 h-10 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center mb-3">
                <Bot className="w-5 h-5" />
              </div>
              <span className="text-[11px] font-mono text-indigo-400 uppercase font-bold">Step 2</span>
              <h4 className="text-sm font-bold text-white mt-1">AI Agent Brain</h4>
              <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
                Interprets request with persistent memory vector.
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-slate-950/70 border border-purple-500/40 text-center flex flex-col items-center shadow-lg shadow-purple-950/40">
              <div className="w-10 h-10 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center mb-3">
                <Cpu className="w-5 h-5" />
              </div>
              <span className="text-[11px] font-mono text-purple-400 uppercase font-bold">Step 3</span>
              <h4 className="text-sm font-bold text-white mt-1">Reasoning Engine</h4>
              <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
                Decides which logical tool is required to execute.
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-slate-950/70 border border-emerald-500/40 text-center flex flex-col items-center shadow-lg shadow-emerald-950/40">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center mb-3">
                <Workflow className="w-5 h-5" />
              </div>
              <span className="text-[11px] font-mono text-emerald-400 uppercase font-bold">Step 4</span>
              <h4 className="text-sm font-bold text-white mt-1">Modular Tools</h4>
              <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
                Executes ATS audit, skill matrix, or question drill.
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-slate-950/70 border border-slate-800 text-center flex flex-col items-center">
              <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center mb-3">
                <Award className="w-5 h-5" />
              </div>
              <span className="text-[11px] font-mono text-slate-500 uppercase font-bold">Step 5</span>
              <h4 className="text-sm font-bold text-white mt-1">Personalized Result</h4>
              <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
                Synthesizes structured feedback & next steps.
              </p>
            </div>
          </div>

          <div className="mt-8 text-center">
            <button
              onClick={onOpenAgentModal}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-indigo-300 border border-slate-700 hover:border-indigo-500 transition-all"
            >
              <Cpu className="w-4 h-4 text-purple-400" />
              <span>Inspect All 7 Agent Tools & Parameters</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 bg-emerald-950/60 px-3 py-1 rounded-full border border-emerald-800/50">
            Student Advantages
          </span>
          <h2 className="mt-3 text-3xl font-extrabold text-white">
            Why College Students Excel with CareerPilot AI
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {benefits.map((b) => {
            const Icon = b.icon;
            return (
              <div key={b.title} className="glass-card rounded-2xl p-6 border border-slate-800">
                <div className="w-10 h-10 rounded-xl bg-indigo-600/20 text-indigo-400 flex items-center justify-center mb-4">
                  <Icon className="w-5 h-5" />
                </div>
                <h4 className="text-base font-bold text-white mb-2">{b.title}</h4>
                <p className="text-xs text-slate-400 leading-relaxed">{b.desc}</p>
              </div>
            );
          })}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-950/90 py-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-indigo-600 flex items-center justify-center text-white">
              <Compass className="w-4 h-4" />
            </div>
            <span className="text-sm font-bold text-white">CareerPilot AI</span>
            <span className="text-xs text-slate-500">• College AI Competition Project</span>
          </div>
          <p className="text-xs text-slate-500">
            Built with React, TypeScript, Express, and Gemini 3.7 Agent Tool Calling.
          </p>
        </div>
      </footer>
    </div>
  );
};
