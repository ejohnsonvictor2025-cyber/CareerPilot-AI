import React from 'react';
import { 
  Compass, 
  Sparkles, 
  ArrowRight, 
  Bot, 
  FileText, 
  Map, 
  Mic, 
  Target, 
  TrendingUp, 
  CheckCircle2, 
  Clock, 
  Cpu, 
  Award, 
  Play, 
  Layers, 
  ExternalLink,
  ChevronRight,
  Zap,
  BookOpen,
  BarChart3
} from 'lucide-react';
import { StudentProfile, CareerRecommendation, CareerRoadmap, ResumeAnalysisResult, ActiveTab } from '../types';

interface DashboardProps {
  profile: StudentProfile;
  recommendation: CareerRecommendation;
  roadmap: CareerRoadmap;
  resumeAnalysis: ResumeAnalysisResult;
  interviewScore: number;
  onNavigate: (tab: ActiveTab) => void;
  onOpenAgentModal: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  profile,
  recommendation,
  roadmap,
  resumeAnalysis,
  interviewScore,
  onNavigate,
  onOpenAgentModal
}) => {
  // Calculate completed tasks in roadmap
  const allTasks = roadmap.steps.flatMap(s => s.tasks);
  const completedTasks = allTasks.filter(t => t.completed).length;
  const totalTasks = allTasks.length || 1;
  const roadmapProgressPct = Math.round((completedTasks / totalTasks) * 100);

  const completedSteps = roadmap.steps.filter(s => s.status === 'completed').length;
  const totalSteps = roadmap.steps.length;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Welcome Banner with Agent Status */}
      <div className="glass-card rounded-3xl p-6 sm:p-8 border border-slate-800 relative overflow-hidden bg-gradient-to-r from-slate-900/90 via-slate-900/60 to-indigo-950/40">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 text-xs font-semibold border border-indigo-500/30">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              Agent State: Active & Monitoring ({profile.year} • {profile.degree})
            </div>
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight">
              Welcome back, {profile.name || 'Student'}! 👋
            </h1>
            <p className="text-sm sm:text-base text-slate-300 max-w-2xl">
              CareerPilot AI is actively optimizing your roadmap to become an{' '}
              <span className="text-indigo-400 font-bold underline decoration-indigo-500/40 underline-offset-4">
                {recommendation.recommendedCareer || profile.preferredCareer || 'AI/ML Engineer'}
              </span>.
            </p>
          </div>

          {/* Quick Agent Actions */}
          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => onNavigate('advisor')}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs font-bold shadow-lg shadow-indigo-600/25 flex items-center gap-2 transition-all"
            >
              <Bot className="w-4 h-4" />
              <span>Talk with AI Advisor</span>
            </button>
            <button
              onClick={onOpenAgentModal}
              className="px-3.5 py-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-800 text-slate-300 hover:text-white text-xs font-bold border border-slate-700 transition-all flex items-center gap-1.5"
            >
              <Cpu className="w-4 h-4 text-purple-400" />
              <span>Agent Internals</span>
            </button>
          </div>
        </div>

        {/* Recommended Next Action Banner */}
        <div className="mt-6 pt-6 border-t border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-950/40 -mx-6 -mb-6 sm:-mx-8 sm:-mb-8 px-6 sm:px-8 py-4 rounded-b-3xl">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
              <Zap className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[11px] font-mono uppercase tracking-wider text-amber-400 font-bold">
                Recommended Next Action:
              </span>
              <p className="text-xs text-slate-200 font-medium">
                Complete Step 2 Checklist: Study Cost Functions, Gradients & Multivariate Calculus
              </p>
            </div>
          </div>
          <button
            onClick={() => onNavigate('roadmap')}
            className="self-start sm:self-center px-3.5 py-1.5 rounded-lg bg-indigo-600/30 hover:bg-indigo-600/50 text-indigo-300 text-xs font-bold border border-indigo-500/40 flex items-center gap-1.5 transition-colors"
          >
            <span>Open Checklist</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* High-Level Metrics Row (5 Cards) */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        {/* Metric 1: Career Match */}
        <div 
          onClick={() => onNavigate('advisor')}
          className="glass-card-hover rounded-2xl p-5 border border-slate-800 cursor-pointer"
        >
          <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
            <span>Career Match</span>
            <Target className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-white font-mono">
            {recommendation.matchPercentage}%
          </div>
          <div className="text-[11px] text-emerald-400 flex items-center gap-1 mt-1 font-medium">
            <TrendingUp className="w-3 h-3" />
            <span>Strong Fit</span>
          </div>
        </div>

        {/* Metric 2: Skill Readiness */}
        <div 
          onClick={() => onNavigate('profile')}
          className="glass-card-hover rounded-2xl p-5 border border-slate-800 cursor-pointer"
        >
          <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
            <span>Skill Readiness</span>
            <BarChart3 className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-indigo-300 font-mono">
            78%
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            {profile.currentSkills.length} Verified Skills
          </div>
        </div>

        {/* Metric 3: Roadmap Progress */}
        <div 
          onClick={() => onNavigate('roadmap')}
          className="glass-card-hover rounded-2xl p-5 border border-slate-800 cursor-pointer"
        >
          <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
            <span>Roadmap</span>
            <Map className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-purple-300 font-mono">
            {roadmapProgressPct}%
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            {completedSteps} of {totalSteps} Milestones
          </div>
        </div>

        {/* Metric 4: Resume Score */}
        <div 
          onClick={() => onNavigate('resume')}
          className="glass-card-hover rounded-2xl p-5 border border-slate-800 cursor-pointer"
        >
          <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
            <span>Resume ATS</span>
            <FileText className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-emerald-300 font-mono">
            {resumeAnalysis.atsScore}/100
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            {resumeAnalysis.atsFeedback.formattingStatus} Format
          </div>
        </div>

        {/* Metric 5: Mock Interview Score */}
        <div 
          onClick={() => onNavigate('interview')}
          className="glass-card-hover rounded-2xl p-5 border border-slate-800 cursor-pointer col-span-2 lg:col-span-1"
        >
          <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
            <span>Interview Grade</span>
            <Mic className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-amber-300 font-mono">
            {interviewScore.toFixed(1)}/10
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            Technical & Voice Evaluated
          </div>
        </div>
      </div>

      {/* Main Two-Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Recommended Career Spotlight & Skill Gap Analysis */}
        <div className="lg:col-span-7 space-y-6">
          {/* Recommended Career Card */}
          <div className="glass-card rounded-2xl p-6 border border-slate-800">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-blue-600/20 text-blue-400 border border-blue-500/30">
                  <Compass className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">
                    Target Trajectory
                  </span>
                  <h3 className="text-lg font-bold text-white">
                    {recommendation.recommendedCareer}
                  </h3>
                </div>
              </div>
              <span className="text-xs font-mono font-bold px-2.5 py-1 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/40">
                {recommendation.matchPercentage}% Match
              </span>
            </div>

            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-5">
              {recommendation.explanation}
            </p>

            {/* Strengths vs Missing Skills */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-slate-800">
              <div>
                <span className="text-[11px] uppercase tracking-wider font-bold text-emerald-400 flex items-center gap-1 mb-2">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Your Skill Strengths
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {recommendation.currentSkillStrengths.map((s) => (
                    <span key={s} className="text-xs px-2.5 py-1 rounded-lg bg-emerald-950/40 text-emerald-300 border border-emerald-800/40 font-medium">
                      {s}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <span className="text-[11px] uppercase tracking-wider font-bold text-amber-400 flex items-center gap-1 mb-2">
                  <Clock className="w-3.5 h-3.5" />
                  Target Skill Gaps
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {recommendation.missingSkills.slice(0, 4).map((s) => (
                    <span key={s} className="text-xs px-2.5 py-1 rounded-lg bg-amber-950/40 text-amber-300 border border-amber-800/40 font-medium">
                      {s}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <div className="mt-5 pt-4 border-t border-slate-800 flex items-center justify-between">
              <span className="text-xs text-slate-400">
                Identified via autonomous tool: <span className="font-mono text-slate-300">recommend_career</span>
              </span>
              <button
                onClick={() => onNavigate('advisor')}
                className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 flex items-center gap-1"
              >
                <span>Discuss with Agent</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Recommended Capstone Projects */}
          <div className="glass-card rounded-2xl p-6 border border-slate-800">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-purple-400" />
                Curated High-Impact Projects for {profile.name}
              </h3>
              <span className="text-xs text-slate-500">Portfolio Builder</span>
            </div>

            <div className="space-y-3">
              {recommendation.recommendedProjects.map((proj, idx) => (
                <div key={idx} className="p-3.5 rounded-xl bg-slate-950/50 border border-slate-800/80 hover:border-indigo-500/40 transition-colors">
                  <div className="flex items-center justify-between mb-1">
                    <h4 className="text-xs sm:text-sm font-bold text-white">{proj.title}</h4>
                    <span className="text-[10px] px-2 py-0.5 rounded font-mono bg-indigo-950/60 text-indigo-300 border border-indigo-800/40">
                      {proj.difficulty}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mb-2 leading-relaxed">{proj.description}</p>
                  <div className="flex flex-wrap gap-1.5">
                    {proj.techStack.map((tech) => (
                      <span key={tech} className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-900 text-slate-300 border border-slate-800">
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Quick Launch Modules & Learning Journey */}
        <div className="lg:col-span-5 space-y-6">
          {/* Quick Launch Cards */}
          <div className="glass-card rounded-2xl p-6 border border-slate-800">
            <h3 className="text-base font-bold text-white mb-4 flex items-center gap-2">
              <Layers className="w-4 h-4 text-indigo-400" />
              Direct Tool Access
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                onClick={() => onNavigate('advisor')}
                className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 hover:border-blue-500/50 text-left transition-all group"
              >
                <Bot className="w-5 h-5 text-blue-400 mb-2 group-hover:scale-110 transition-transform" />
                <div className="text-xs font-bold text-white">AI Advisor Chat</div>
                <div className="text-[11px] text-slate-400 mt-0.5">Ask career questions</div>
              </button>

              <button
                onClick={() => onNavigate('roadmap')}
                className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 hover:border-purple-500/50 text-left transition-all group"
              >
                <Map className="w-5 h-5 text-purple-400 mb-2 group-hover:scale-110 transition-transform" />
                <div className="text-xs font-bold text-white">Career Roadmap</div>
                <div className="text-[11px] text-slate-400 mt-0.5">Semester checklist</div>
              </button>

              <button
                onClick={() => onNavigate('resume')}
                className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 hover:border-emerald-500/50 text-left transition-all group"
              >
                <FileText className="w-5 h-5 text-emerald-400 mb-2 group-hover:scale-110 transition-transform" />
                <div className="text-xs font-bold text-white">Resume Analyzer</div>
                <div className="text-[11px] text-slate-400 mt-0.5">ATS bullet rewrites</div>
              </button>

              <button
                onClick={() => onNavigate('interview')}
                className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 hover:border-amber-500/50 text-left transition-all group"
              >
                <Mic className="w-5 h-5 text-amber-400 mb-2 group-hover:scale-110 transition-transform" />
                <div className="text-xs font-bold text-white">Mock Interview</div>
                <div className="text-[11px] text-slate-400 mt-0.5">Turn-by-turn testing</div>
              </button>
            </div>
          </div>

          {/* Active Roadmap Timeline Snapshot */}
          <div className="glass-card rounded-2xl p-6 border border-slate-800">
            <div className="flex items-center justify-between mb-4">
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-500">Curriculum Path</span>
                <h3 className="text-sm font-bold text-white">{roadmap.career}</h3>
              </div>
              <button
                onClick={() => onNavigate('roadmap')}
                className="text-xs text-indigo-400 hover:text-indigo-300 font-semibold"
              >
                View Full
              </button>
            </div>

            <div className="space-y-3 relative before:absolute before:inset-0 before:left-3 before:w-0.5 before:bg-slate-800">
              {roadmap.steps.slice(0, 4).map((step, index) => {
                const isDone = step.status === 'completed';
                const isCurr = step.status === 'in-progress';
                return (
                  <div key={step.id} className="relative flex items-start gap-3 pl-6">
                    <div
                      className={`absolute left-1.5 top-1 w-3.5 h-3.5 rounded-full border-2 -translate-x-1/2 ${
                        isDone
                          ? 'bg-emerald-500 border-emerald-400'
                          : isCurr
                          ? 'bg-indigo-500 border-indigo-400 ring-4 ring-indigo-500/20'
                          : 'bg-slate-800 border-slate-600'
                      }`}
                    />
                    <div className="w-full">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-slate-200 truncate">{step.title}</span>
                        <span className="text-[10px] text-slate-400 shrink-0">{step.estimatedTime}</span>
                      </div>
                      <span className={`text-[10px] uppercase font-semibold ${isDone ? 'text-emerald-400' : isCurr ? 'text-indigo-400' : 'text-slate-500'}`}>
                        {step.status}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
