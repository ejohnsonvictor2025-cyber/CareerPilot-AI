import React, { useState } from 'react';
import { 
  Cpu, 
  Layers, 
  Sparkles, 
  Terminal, 
  CheckCircle2, 
  ArrowRight, 
  X, 
  FileText, 
  Compass, 
  Award, 
  BookOpen, 
  Database,
  Code2,
  Workflow
} from 'lucide-react';
import { AGENT_TOOLS_REGISTRY } from '../data/demoData';

interface AgentFlowModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AgentFlowModal: React.FC<AgentFlowModalProps> = ({ isOpen, onClose }) => {
  const [selectedTool, setSelectedTool] = useState(AGENT_TOOLS_REGISTRY[0]);
  const [activeStep, setActiveStep] = useState<number>(3);

  if (!isOpen) return null;

  const steps = [
    {
      number: '01',
      title: 'Perception & Intent Recognition',
      desc: 'Parses unstructured student query or click trigger to discern current task requirements.',
      icon: Terminal,
      highlight: 'Semantic Intent Mapping'
    },
    {
      number: '02',
      title: 'Context & Profile Memory',
      desc: 'Retrieves student profile (degree, year, verified skills, career goal, previous answers).',
      icon: Database,
      highlight: 'Persistent State Vector'
    },
    {
      number: '03',
      title: 'Autonomous Reasoning & Planning',
      desc: 'Agent evaluates available tools, creates execution plan, and decides function calls.',
      icon: Cpu,
      highlight: 'Multi-Step Tool Selection'
    },
    {
      number: '04',
      title: 'Dedicated Tool Execution',
      desc: 'Executes domain-specific tools (ATS scanner, roadmap synthesizer, question evaluator).',
      icon: Layers,
      highlight: '7 Modular Logical Tools'
    },
    {
      number: '05',
      title: 'Personalized Synthesis',
      desc: 'Generates structured JSON & actionable natural language output tailored to college timeline.',
      icon: Sparkles,
      highlight: 'Zero Generic Advice'
    }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden my-8">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-gradient-to-tr from-indigo-500 to-purple-600 text-white shadow-lg shadow-indigo-500/25">
              <Workflow className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-white flex items-center gap-2">
                CareerPilot AI Agent Architecture
                <span className="text-xs font-medium px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  Competition Blueprint
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                User → AI Agent Brain → Reasoning & Memory → Tool Invocations → Personalized Guidance
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-8 max-h-[80vh] overflow-y-auto">
          {/* Agent Workflow Steps */}
          <div>
            <h4 className="text-sm font-semibold uppercase tracking-wider text-slate-400 mb-4 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-400" />
              Autonomous Agent Decision Pipeline
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
              {steps.map((s, idx) => {
                const Icon = s.icon;
                const isSelected = activeStep === idx + 1;
                return (
                  <div
                    key={s.number}
                    onClick={() => setActiveStep(idx + 1)}
                    className={`cursor-pointer rounded-xl p-4 border transition-all relative ${
                      isSelected
                        ? 'bg-indigo-950/50 border-indigo-500 shadow-lg shadow-indigo-950/50'
                        : 'bg-slate-800/40 border-slate-700/60 hover:border-slate-600'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className={`text-xs font-mono font-bold ${isSelected ? 'text-indigo-400' : 'text-slate-500'}`}>
                        {s.number}
                      </span>
                      <Icon className={`w-4 h-4 ${isSelected ? 'text-indigo-400' : 'text-slate-400'}`} />
                    </div>
                    <h5 className="text-xs font-bold text-slate-100 mb-1 leading-tight">{s.title}</h5>
                    <p className="text-[11px] text-slate-400 line-clamp-3 mb-2">{s.desc}</p>
                    <span className="inline-block text-[10px] font-semibold text-indigo-300/90 bg-indigo-900/40 px-2 py-0.5 rounded-md border border-indigo-800/40">
                      {s.highlight}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Interactive Agent Tool Matrix */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-sm font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-2">
                <Layers className="w-4 h-4 text-purple-400" />
                Integrated Agent Tool Registry ({AGENT_TOOLS_REGISTRY.length} Functional Tools)
              </h4>
              <span className="text-xs text-slate-500">Click any tool to inspect interface</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
              {/* Tool List */}
              <div className="md:col-span-5 space-y-2 max-h-72 overflow-y-auto pr-1">
                {AGENT_TOOLS_REGISTRY.map((tool) => {
                  const isSelected = selectedTool.name === tool.name;
                  return (
                    <button
                      key={tool.name}
                      onClick={() => setSelectedTool(tool)}
                      className={`w-full text-left p-3 rounded-xl border transition-all text-xs font-mono flex items-center justify-between ${
                        isSelected
                          ? 'bg-purple-950/40 border-purple-500 text-purple-200'
                          : 'bg-slate-800/40 border-slate-700/60 text-slate-300 hover:bg-slate-800 hover:text-white'
                      }`}
                    >
                      <div className="flex items-center gap-2 truncate">
                        <Code2 className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                        <span className="truncate">{tool.name}</span>
                      </div>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700 shrink-0">
                        {tool.category}
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* Tool Inspector Card */}
              <div className="md:col-span-7 bg-slate-950/80 rounded-xl p-5 border border-slate-800 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
                    <div>
                      <span className="text-xs text-purple-400 font-mono font-bold">Tool Signature</span>
                      <h5 className="text-base font-bold text-white font-mono">{selectedTool.name}()</h5>
                    </div>
                    <span className="text-xs px-2.5 py-1 rounded-md bg-purple-900/30 text-purple-300 border border-purple-800/40">
                      {selectedTool.category}
                    </span>
                  </div>

                  <div className="space-y-3">
                    <div>
                      <div className="text-[11px] uppercase tracking-wider text-slate-500 font-semibold mb-1">
                        System Purpose
                      </div>
                      <p className="text-xs text-slate-300 leading-relaxed">{selectedTool.purpose}</p>
                    </div>

                    <div>
                      <div className="text-[11px] uppercase tracking-wider text-slate-500 font-semibold mb-1">
                        Functional Description
                      </div>
                      <p className="text-xs text-slate-300 leading-relaxed">{selectedTool.description}</p>
                    </div>

                    <div>
                      <div className="text-[11px] uppercase tracking-wider text-slate-500 font-semibold mb-1.5">
                        Required Parameters
                      </div>
                      <div className="flex flex-wrap gap-1.5">
                        {selectedTool.parameters.map((param) => (
                          <span
                            key={param}
                            className="text-[11px] font-mono px-2 py-0.5 rounded bg-indigo-950/60 text-indigo-300 border border-indigo-800/50"
                          >
                            {param}: string
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
                  <span className="flex items-center gap-1.5 text-emerald-400">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Production Ready LLM Function
                  </span>
                  <span className="font-mono text-[11px] text-slate-500">Model: Gemini 3.7 Flash</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 bg-slate-950/80 border-t border-slate-800 flex items-center justify-between">
          <p className="text-xs text-slate-400">
            Engineered for autonomous student career progression with server-side validation.
          </p>
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white transition-colors"
          >
            Understood
          </button>
        </div>
      </div>
    </div>
  );
};
